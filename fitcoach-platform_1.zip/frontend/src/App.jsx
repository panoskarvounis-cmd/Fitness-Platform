import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './AuthContext';
import { Protected } from './Protected';

import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';

import Onboarding from './pages/trainee/Onboarding';
import TraineeDashboard from './pages/trainee/Dashboard';
import Coaches from './pages/trainee/Coaches';
import Plan from './pages/trainee/Plan';

import CoachPending from './pages/coach/Pending';
import CoachDashboard from './pages/coach/Dashboard';
import Roster from './pages/coach/Roster';
import Availability from './pages/coach/Availability';
import CoachProfile from './pages/coach/Profile';

import AdminDashboard from './pages/admin/Dashboard';
import AdminUsers from './pages/admin/Users';
import Applications from './pages/admin/Applications';
import Moderation from './pages/admin/Moderation';
import Financials from './pages/admin/Financials';
import AuditLog from './pages/admin/AuditLog';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route path="/trainee/onboarding" element={<Protected roles={['trainee']}><Onboarding /></Protected>} />
          <Route path="/trainee" element={<Protected roles={['trainee']}><TraineeDashboard /></Protected>} />
          <Route path="/trainee/coaches" element={<Protected roles={['trainee']}><Coaches /></Protected>} />
          <Route path="/trainee/plan" element={<Protected roles={['trainee']}><Plan /></Protected>} />

          <Route path="/coach/pending" element={<Protected roles={['coach']}><CoachPending /></Protected>} />
          <Route path="/coach" element={<Protected roles={['coach']}><CoachDashboard /></Protected>} />
          <Route path="/coach/roster" element={<Protected roles={['coach']}><Roster /></Protected>} />
          <Route path="/coach/availability" element={<Protected roles={['coach']}><Availability /></Protected>} />
          <Route path="/coach/profile" element={<Protected roles={['coach']}><CoachProfile /></Protected>} />

          <Route path="/admin" element={<Protected roles={['admin']}><AdminDashboard /></Protected>} />
          <Route path="/admin/users" element={<Protected roles={['admin']}><AdminUsers /></Protected>} />
          <Route path="/admin/applications" element={<Protected roles={['admin']}><Applications /></Protected>} />
          <Route path="/admin/moderation" element={<Protected roles={['admin']}><Moderation /></Protected>} />
          <Route path="/admin/financials" element={<Protected roles={['admin']}><Financials /></Protected>} />
          <Route path="/admin/audit" element={<Protected roles={['admin']}><AuditLog /></Protected>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
