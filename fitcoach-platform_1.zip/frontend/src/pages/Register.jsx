import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../AuthContext';
import { Card, Field, Input, Select, Button, ErrorBanner } from '../components/ui';

export default function Register() {
  const [params] = useSearchParams();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState(params.get('role') === 'coach' ? 'coach' : 'trainee');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const nav = useNavigate();

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token, user } = await api.register({ name, email, password, role });
      login(token, user);
      if (role === 'coach' && user.status === 'pending') {
        nav('/coach/pending');
      } else {
        nav('/trainee/onboarding');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full bg-paper flex items-center justify-center px-6 py-10">
      <Card className="w-full max-w-sm">
        <h1 className="font-display font-bold text-2xl mb-1">Create your account</h1>
        <p className="text-ink/50 text-sm mb-6">Join as a trainee or apply as a coach.</p>
        <ErrorBanner message={error} />
        <form onSubmit={submit}>
          <Field label="I am a…">
            <Select value={role} onChange={(e) => setRole(e.target.value)}>
              <option value="trainee">Trainee</option>
              <option value="coach">Coach (requires approval)</option>
            </Select>
          </Field>
          <Field label="Full name">
            <Input required value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password">
            <Input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <Button type="submit" disabled={loading} className="w-full mt-2">{loading ? 'Creating…' : 'Create account'}</Button>
        </form>
        <p className="text-sm text-ink/50 mt-5">
          Already have an account? <Link to="/login" className="text-coral font-semibold">Log in</Link>
        </p>
      </Card>
    </div>
  );
}
