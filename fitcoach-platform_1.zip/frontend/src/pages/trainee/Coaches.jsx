import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Button, Badge, ErrorBanner } from '../../components/ui';

export default function Coaches() {
  const { token, user } = useAuth();
  const [coaches, setCoaches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [slots, setSlots] = useState([]);
  const [error, setError] = useState('');
  const [booked, setBooked] = useState('');

  useEffect(() => { api.getDirectory(token).then(setCoaches); }, [token]);

  async function openCoach(c) {
    setSelected(c);
    setError('');
    setBooked('');
    const s = await api.getAvailability(token, c.id);
    setSlots(s);
  }

  async function book(slot) {
    setError('');
    try {
      await api.createBooking(token, { coach_id: selected.id, slot_id: slot.id, service_type: '1:1 session' });
      setBooked(`Booked with ${selected.name} for ${new Date(slot.start_time).toLocaleString()}`);
      setSlots((s) => s.filter((x) => x.id !== slot.id));
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Find a coach</h1>
      <p className="text-ink/50 mb-8">Browse verified coaches and book a live slot.</p>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          {coaches.map((c) => (
            <Card key={c.id} className={selected?.id === c.id ? 'ring-2 ring-coral' : ''}>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-display font-bold text-lg">{c.name}</h3>
                  <p className="text-sm text-ink/60 mt-1 mb-2 max-w-sm">{c.bio}</p>
                  <div className="flex gap-1.5 flex-wrap mb-2">
                    {c.specialties.map((s) => <Badge key={s}>{s.replace('_', ' ')}</Badge>)}
                  </div>
                  <div className="text-sm font-semibold">${c.hourly_rate}/session</div>
                </div>
                <Button className="!px-4 !py-1.5 !text-xs" onClick={() => openCoach(c)}>View slots</Button>
              </div>
            </Card>
          ))}
          {coaches.length === 0 && <p className="text-sm text-ink/40">No approved coaches yet.</p>}
        </div>

        <Card className="h-fit sticky top-24">
          {!selected && <p className="text-sm text-ink/40">Select a coach to see availability.</p>}
          {selected && (
            <div>
              <h3 className="font-display font-bold text-lg mb-1">{selected.name}</h3>
              <p className="text-xs text-ink/40 mb-4">Pick an open slot to book instantly.</p>
              <ErrorBanner message={error} />
              {booked && <div className="mb-4 text-sm bg-moss/10 text-moss border border-moss/20 rounded-lg px-4 py-2.5">{booked}</div>}
              <div className="space-y-2">
                {slots.map((s) => (
                  <div key={s.id} className="flex items-center justify-between border border-black/10 rounded-lg px-3 py-2.5 text-sm">
                    <span>{new Date(s.start_time).toLocaleString()}</span>
                    <Button className="!px-3 !py-1 !text-xs" onClick={() => book(s)}>Book</Button>
                  </div>
                ))}
                {slots.length === 0 && <p className="text-sm text-ink/40">No open slots right now.</p>}
              </div>
            </div>
          )}
        </Card>
      </div>
    </AppLayout>
  );
}
