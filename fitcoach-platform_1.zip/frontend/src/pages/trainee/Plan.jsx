import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Badge, Button, Input } from '../../components/ui';

export default function Plan() {
  const { token, user } = useAuth();
  const [programs, setPrograms] = useState([]);
  const [logInputs, setLogInputs] = useState({});
  const [savedIds, setSavedIds] = useState(new Set());

  function load() {
    api.getPrograms(token, user.id).then(setPrograms);
  }
  useEffect(load, [token, user.id]);

  async function logItem(item) {
    const input = logInputs[item.id] || {};
    await api.logWorkout(token, {
      program_item_id: item.id,
      actual_sets: Number(input.sets ?? item.sets) || null,
      actual_reps: Number(input.reps ?? item.reps) || null,
      actual_weight: Number(input.weight ?? item.weight) || null,
      rpe: Number(input.rpe) || null,
    });
    setSavedIds((s) => new Set([...s, item.id]));
  }

  const days = ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'];

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">My plan</h1>
      <p className="text-ink/50 mb-8">Log your actuals against each prescribed exercise.</p>

      {programs.length === 0 && <Card><p className="text-sm text-ink/40">No program assigned yet — book a coach to get started.</p></Card>}

      {programs.map((p) => (
        <Card key={p.id} className="mb-5">
          <div className="flex items-center justify-between mb-1">
            <h2 className="font-display font-bold text-lg">{p.title}</h2>
            <Badge tone={p.status === 'active' ? 'good' : p.status === 'draft' ? 'warn' : 'default'}>{p.status}</Badge>
          </div>
          {p.status === 'draft' && (
            <p className="text-xs text-coral mb-4">Awaiting your coach's review and approval before this becomes active.</p>
          )}
          {p.rules && (
            <div className="text-xs bg-ink/[0.03] rounded-lg p-3 mb-4 text-ink/60">
              <span className="font-semibold">Suggested by rules engine:</span> {p.rules.draft.split.replace('_', ' ')} split,{' '}
              {p.rules.draft.frequencyPerWeek}x/week, {p.rules.draft.intensityZone} intensity.
              {p.rules.draft.restrictions.length > 0 && (
                <div className="mt-1">Restrictions: {p.rules.draft.restrictions.join(' ')}</div>
              )}
            </div>
          )}

          <div className="space-y-3 mt-4">
            {p.items.map((item) => (
              <div key={item.id} className="border border-black/10 rounded-lg p-3">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-xs text-ink/40 mr-2">{days[item.day_index] || `Day ${item.day_index + 1}`}</span>
                    <span className="font-semibold text-sm">{item.exercise_name}</span>
                  </div>
                  <span className="text-xs text-ink/40">Target: {item.sets}x{item.reps}{item.weight ? ` @ ${item.weight}kg` : ''}</span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  <Input placeholder="sets" defaultValue={item.sets} onChange={(e) => setLogInputs((s) => ({ ...s, [item.id]: { ...s[item.id], sets: e.target.value } }))} />
                  <Input placeholder="reps" defaultValue={item.reps} onChange={(e) => setLogInputs((s) => ({ ...s, [item.id]: { ...s[item.id], reps: e.target.value } }))} />
                  <Input placeholder="weight" defaultValue={item.weight || ''} onChange={(e) => setLogInputs((s) => ({ ...s, [item.id]: { ...s[item.id], weight: e.target.value } }))} />
                  <Input placeholder="RPE 1-10" onChange={(e) => setLogInputs((s) => ({ ...s, [item.id]: { ...s[item.id], rpe: e.target.value } }))} />
                </div>
                <Button className="!text-xs !px-3 !py-1 mt-2" onClick={() => logItem(item)}>
                  {savedIds.has(item.id) ? 'Logged ✓' : 'Log set'}
                </Button>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </AppLayout>
  );
}
