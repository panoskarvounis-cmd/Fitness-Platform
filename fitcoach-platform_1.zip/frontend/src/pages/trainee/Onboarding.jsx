import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import { Card, Field, Input, Select, Button, ErrorBanner } from '../../components/ui';

const PARQ_QUESTIONS = [
  ['heart_condition', 'Has a doctor ever said you have a heart condition?'],
  ['chest_pain', 'Do you feel pain in your chest during physical activity?'],
  ['dizziness', 'Do you lose balance or dizziness, or have you lost consciousness?'],
  ['bone_joint_problem', 'Do you have a bone or joint problem that could worsen with exercise?'],
  ['blood_pressure_meds', 'Are you currently on blood pressure or heart medication?'],
  ['other_reason_not_to_exercise', 'Do you know of any other reason you should not exercise?'],
];

export default function Onboarding() {
  const { token, user } = useAuth();
  const nav = useNavigate();
  const [step, setStep] = useState(1);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const [demo, setDemo] = useState({ age: '', sex: 'F', height_cm: '', weight_kg: '' });
  const [medical, setMedical] = useState({ injuries: '', chronic_conditions: '', medications: '', pregnancy_status: false });
  const [parq, setParq] = useState(Object.fromEntries(PARQ_QUESTIONS.map(([k]) => [k, false])));
  const [goal, setGoal] = useState({ type: 'weight_loss', target_value: '', target_date: '' });
  const [activityLevel, setActivityLevel] = useState('sedentary');

  async function finish() {
    setSaving(true);
    setError('');
    try {
      const answers = {
        age: Number(demo.age) || null,
        sex: demo.sex,
        height_cm: Number(demo.height_cm) || null,
        weight_kg: Number(demo.weight_kg) || null,
        injuries: medical.injuries ? medical.injuries.split(',').map((s) => s.trim()) : [],
        chronic_conditions: medical.chronic_conditions ? medical.chronic_conditions.split(',').map((s) => s.trim()) : [],
        medications: medical.medications ? medical.medications.split(',').map((s) => s.trim()) : [],
        pregnancy_status: medical.pregnancy_status,
        ...parq,
      };
      const intakeRes = await api.submitHealthIntake(token, answers);
      await api.createObjective(token, { type: goal.type, target_value: Number(goal.target_value) || null, target_date: goal.target_date || null });
      if (demo.weight_kg) await api.addBodyMetric(token, { weight: Number(demo.weight_kg) });

      sessionStorage.setItem('fc_activity_level', activityLevel);
      nav('/trainee');
      if (intakeRes.parqFlag) {
        alert('Your answers flagged a readiness item on the PAR-Q screening. Your coach will review this before your plan goes active, and we recommend checking with a physician before starting an intense program. This is not a medical diagnosis.');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-full bg-paper flex items-center justify-center px-6 py-10">
      <Card className="w-full max-w-lg">
        <div className="flex items-center gap-1.5 mb-6">
          {[1, 2, 3, 4].map((s) => (
            <div key={s} className={`h-1.5 flex-1 rounded-full ${s <= step ? 'bg-coral' : 'bg-ink/10'}`} />
          ))}
        </div>
        <ErrorBanner message={error} />

        {step === 1 && (
          <div>
            <h2 className="font-display font-bold text-xl mb-1">A little about you, {user?.name?.split(' ')[0]}</h2>
            <p className="text-ink/50 text-sm mb-5">This helps your coach build a plan that fits your body.</p>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Age"><Input type="number" value={demo.age} onChange={(e) => setDemo({ ...demo, age: e.target.value })} /></Field>
              <Field label="Sex">
                <Select value={demo.sex} onChange={(e) => setDemo({ ...demo, sex: e.target.value })}>
                  <option value="F">Female</option><option value="M">Male</option><option value="O">Other / prefer not to say</option>
                </Select>
              </Field>
              <Field label="Height (cm)"><Input type="number" value={demo.height_cm} onChange={(e) => setDemo({ ...demo, height_cm: e.target.value })} /></Field>
              <Field label="Weight (kg)"><Input type="number" value={demo.weight_kg} onChange={(e) => setDemo({ ...demo, weight_kg: e.target.value })} /></Field>
            </div>
            <Field label="Current activity level">
              <Select value={activityLevel} onChange={(e) => setActivityLevel(e.target.value)}>
                <option value="sedentary">Sedentary — little to no exercise</option>
                <option value="moderate">Moderate — 1-3x/week</option>
                <option value="active">Active — 4+ times/week</option>
              </Select>
            </Field>
            <Button className="w-full mt-2" onClick={() => setStep(2)}>Continue</Button>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2 className="font-display font-bold text-xl mb-1">Medical history</h2>
            <p className="text-ink/50 text-sm mb-5">Only you, your assigned coach, and audited admin staff can see this.</p>
            <Field label="Injuries (comma-separated)" hint="e.g. lower_back, knee"><Input value={medical.injuries} onChange={(e) => setMedical({ ...medical, injuries: e.target.value })} /></Field>
            <Field label="Chronic conditions (comma-separated)" hint="e.g. asthma, hypertension"><Input value={medical.chronic_conditions} onChange={(e) => setMedical({ ...medical, chronic_conditions: e.target.value })} /></Field>
            <Field label="Current medications (comma-separated)"><Input value={medical.medications} onChange={(e) => setMedical({ ...medical, medications: e.target.value })} /></Field>
            <label className="flex items-center gap-2 text-sm mb-4">
              <input type="checkbox" checked={medical.pregnancy_status} onChange={(e) => setMedical({ ...medical, pregnancy_status: e.target.checked })} />
              Currently pregnant
            </label>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
              <Button className="flex-1" onClick={() => setStep(3)}>Continue</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <h2 className="font-display font-bold text-xl mb-1">Readiness screening (PAR-Q)</h2>
            <p className="text-ink/50 text-sm mb-5">Answer honestly — a "yes" just means your coach reviews before intensity increases, not that you can't participate.</p>
            <div className="space-y-3 mb-4">
              {PARQ_QUESTIONS.map(([key, q]) => (
                <label key={key} className="flex items-start gap-2.5 text-sm bg-ink/[0.03] rounded-lg p-3">
                  <input type="checkbox" className="mt-0.5" checked={parq[key]} onChange={(e) => setParq({ ...parq, [key]: e.target.checked })} />
                  <span>{q}</span>
                </label>
              ))}
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setStep(2)}>Back</Button>
              <Button className="flex-1" onClick={() => setStep(4)}>Continue</Button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div>
            <h2 className="font-display font-bold text-xl mb-1">What's your main goal?</h2>
            <p className="text-ink/50 text-sm mb-5">You can add more objectives later.</p>
            <Field label="Goal type">
              <Select value={goal.type} onChange={(e) => setGoal({ ...goal, type: e.target.value })}>
                <option value="weight_loss">Weight loss</option>
                <option value="muscle_gain">Muscle gain</option>
                <option value="endurance">Endurance</option>
                <option value="rehab">Rehab</option>
                <option value="general_fitness">General fitness</option>
              </Select>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Target value" hint="e.g. target weight in kg"><Input type="number" value={goal.target_value} onChange={(e) => setGoal({ ...goal, target_value: e.target.value })} /></Field>
              <Field label="Target date"><Input type="date" value={goal.target_date} onChange={(e) => setGoal({ ...goal, target_date: e.target.value })} /></Field>
            </div>
            <div className="flex gap-2 mt-2">
              <Button variant="ghost" onClick={() => setStep(3)}>Back</Button>
              <Button className="flex-1" disabled={saving} onClick={finish}>{saving ? 'Saving…' : 'Finish setup'}</Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
