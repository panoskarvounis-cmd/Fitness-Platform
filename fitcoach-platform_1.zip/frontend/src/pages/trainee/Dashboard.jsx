import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Bar, Badge, Button } from '../../components/ui';

export default function TraineeDashboard() {
  const { token, user } = useAuth();
  const [kpi, setKpi] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [metrics, setMetrics] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.getKpi(token, user.id),
      api.getMyBookings(token),
      api.getBodyMetrics(token, user.id),
    ]).then(([k, b, m]) => {
      setKpi(k); setBookings(b); setMetrics(m);
    }).finally(() => setLoading(false));
  }, [token, user.id]);

  if (loading) return <AppLayout><p className="text-ink/40">Loading your dashboard…</p></AppLayout>;

  const weightSeries = metrics.map((m, i) => ({ name: `#${i + 1}`, weight: m.weight }));

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Hey {user.name.split(' ')[0]}</h1>
      <p className="text-ink/50 mb-8">Here's where your training stands today.</p>

      <div className="grid md:grid-cols-3 gap-5 mb-6">
        <Card>
          <div className="text-ink/50 text-sm font-semibold mb-2">Session adherence</div>
          <div className="font-display text-3xl font-bold mb-3">{kpi.adherenceRate}%</div>
          <Bar pct={kpi.adherenceRate} tone={kpi.adherenceRate < 50 ? 'coral' : 'moss'} />
          {kpi.atRisk && <p className="text-xs text-coral mt-2 font-medium">Falling behind — try logging your next session.</p>}
        </Card>
        <Card>
          <div className="text-ink/50 text-sm font-semibold mb-2">Weight trend</div>
          <div className="font-display text-3xl font-bold mb-3">{kpi.latestWeight ? `${kpi.latestWeight} kg` : '—'}</div>
          <div className="h-16">
            {weightSeries.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weightSeries}>
                  <Line type="monotone" dataKey="weight" stroke="#FF5A3C" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : <p className="text-xs text-ink/40">Log another weigh-in to see a trend.</p>}
          </div>
        </Card>
        <Card>
          <div className="text-ink/50 text-sm font-semibold mb-2">Goal progress</div>
          {kpi.goalProgress.length ? kpi.goalProgress.map((g, i) => (
            <div key={i} className="mb-2">
              <div className="text-xs text-ink/50 mb-1 capitalize">{g.objective.type.replace('_', ' ')}</div>
              <Bar pct={g.progressPct ?? 0} tone="moss" />
            </div>
          )) : <p className="text-xs text-ink/40">No objective on file yet.</p>}
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-lg">Upcoming sessions</h2>
            <Link to="/trainee/coaches"><Button variant="ghost" className="!text-xs !px-3 !py-1.5">Book more</Button></Link>
          </div>
          {bookings.length === 0 && <p className="text-sm text-ink/40">No sessions booked yet.</p>}
          <div className="space-y-2">
            {bookings.map((b) => (
              <div key={b.id} className="flex items-center justify-between border border-black/10 rounded-lg px-3 py-2.5 text-sm">
                <div>
                  <div className="font-semibold">{b.counterpart_name}</div>
                  <div className="text-ink/40 text-xs">{new Date(b.start_time).toLocaleString()}</div>
                </div>
                <Badge tone={b.status === 'confirmed' ? 'good' : b.status === 'cancelled' ? 'bad' : 'default'}>{b.status}</Badge>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h2 className="font-display font-bold text-lg mb-4">A note on your plan</h2>
          <p className="text-sm text-ink/60 leading-relaxed mb-3">
            Any training direction FitCoach suggests is a rules-based starting point, not a medical
            diagnosis. Your assigned coach reviews and approves every plan before it goes active,
            especially if your readiness screening flagged anything.
          </p>
          <Link to="/trainee/plan"><Button variant="dark" className="!text-xs">View my plan</Button></Link>
        </Card>
      </div>
    </AppLayout>
  );
}
