import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

export default function Moderation() {
  const { token } = useAuth();
  const [reviews, setReviews] = useState([]);

  function load() { api.adminPendingReviews(token).then(setReviews); }
  useEffect(load, [token]);

  async function decide(id, decision) {
    await api.adminModerateReview(token, id, decision);
    load();
  }

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Content moderation</h1>
      <p className="text-slate-500 text-sm mb-6">Trainee reviews awaiting publish approval.</p>

      <div className="space-y-3">
        {reviews.map((r) => (
          <div key={r.id} className="border border-control-line rounded-lg p-4 bg-control-panel/40">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-amber-400 text-sm">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
                </div>
                <p className="text-sm text-slate-300 max-w-lg">{r.comment}</p>
              </div>
              <div className="flex gap-2 shrink-0">
                <button className="bg-control-accent text-control-bg text-xs font-semibold px-3 py-1.5 rounded-md" onClick={() => decide(r.id, 'approve')}>Approve</button>
                <button className="border border-red-400 text-red-400 text-xs px-3 py-1.5 rounded-md" onClick={() => decide(r.id, 'reject')}>Reject</button>
              </div>
            </div>
          </div>
        ))}
        {reviews.length === 0 && <p className="text-slate-500 text-sm">Nothing pending review.</p>}
      </div>
    </AdminLayout>
  );
}
