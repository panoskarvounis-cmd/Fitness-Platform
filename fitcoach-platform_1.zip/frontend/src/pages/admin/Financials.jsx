import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

export default function Financials() {
  const { token } = useAuth();
  const [data, setData] = useState(null);

  useEffect(() => { api.adminFinancials(token).then(setData); }, [token]);
  if (!data) return <AdminLayout><p className="text-slate-500">Loading…</p></AdminLayout>;

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Financials</h1>
      <p className="text-slate-500 text-sm mb-2">Transactions, revenue, and payouts.</p>
      <p className="text-xs text-amber-400 mb-6">Payments are mocked via a stub provider — connect real Stripe Connect credentials before production use.</p>

      <div className="border border-control-line rounded-lg p-5 bg-control-panel/40 mb-6 w-fit">
        <div className="text-slate-500 text-xs uppercase tracking-wider mb-2">Total revenue</div>
        <div className="font-display text-3xl font-bold text-slate-100">${data.totalRevenue.toFixed(2)}</div>
      </div>

      <div className="border border-control-line rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-control-panel text-slate-400 text-xs uppercase">
            <tr><th className="text-left px-4 py-2">Amount</th><th className="text-left px-4 py-2">Status</th><th className="text-left px-4 py-2">Provider ref</th></tr>
          </thead>
          <tbody>
            {data.payments.map((p) => (
              <tr key={p.id} className="border-t border-control-line">
                <td className="px-4 py-2.5 text-slate-100">${p.amount.toFixed(2)}</td>
                <td className="px-4 py-2.5"><span className="text-xs bg-emerald-900 text-emerald-300 px-2 py-0.5 rounded-full">{p.status}</span></td>
                <td className="px-4 py-2.5 text-slate-500 text-xs">{p.provider_ref}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {data.payments.length === 0 && <p className="text-slate-500 text-sm p-4">No transactions yet.</p>}
      </div>
    </AdminLayout>
  );
}
