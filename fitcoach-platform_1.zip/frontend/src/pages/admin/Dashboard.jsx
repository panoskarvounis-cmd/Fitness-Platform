import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

function Panel({ label, value, sub }) {
  return (
    <div className="border border-control-line rounded-lg p-5 bg-control-panel/40">
      <div className="text-slate-500 text-xs uppercase tracking-wider mb-2">{label}</div>
      <div className="font-display text-3xl font-bold text-slate-100">{value}</div>
      {sub && <div className="text-slate-500 text-xs mt-1">{sub}</div>}
    </div>
  );
}

export default function AdminDashboard() {
  const { token } = useAuth();
  const [d, setD] = useState(null);

  useEffect(() => { api.adminDashboard(token).then(setD); }, [token]);
  if (!d) return <AdminLayout><p className="text-slate-500">Loading…</p></AdminLayout>;

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Platform overview</h1>
      <p className="text-slate-500 text-sm mb-8">Live snapshot across all roles.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Panel label="Active users" value={d.activeUsers} />
        <Panel label="Bookings today" value={d.bookingsToday} />
        <Panel label="Revenue (mock)" value={`$${d.revenue.toFixed(2)}`} />
        <Panel label="Active coaches" value={d.coachCount} sub={`${d.pendingCoaches} pending review`} />
      </div>

      <div className="border border-control-line rounded-lg p-5 bg-control-panel/40">
        <div className="text-slate-500 text-xs uppercase tracking-wider mb-3">Top specialties</div>
        <div className="flex flex-wrap gap-2">
          {Object.entries(d.topSpecialties).map(([s, c]) => (
            <span key={s} className="text-xs bg-control-bg border border-control-line px-3 py-1.5 rounded-full text-slate-300">
              {s.replace('_', ' ')} · {c}
            </span>
          ))}
        </div>
      </div>
    </AdminLayout>
  );
}
