import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

export default function Applications() {
  const { token } = useAuth();
  const [apps, setApps] = useState([]);

  function load() { api.adminCoachApplications(token).then(setApps); }
  useEffect(load, [token]);

  async function decide(userId, decision) {
    await api.adminReviewApplication(token, userId, decision, '');
    load();
  }

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Coach applications</h1>
      <p className="text-slate-500 text-sm mb-6">Approve or reject pending coach onboarding requests.</p>

      <div className="space-y-3">
        {apps.map((a) => (
          <div key={a.id} className="border border-control-line rounded-lg p-4 bg-control-panel/40">
            <div className="flex items-start justify-between">
              <div>
                <div className="font-semibold text-slate-100">{a.name}</div>
                <div className="text-slate-500 text-xs mb-2">{a.email}</div>
                <p className="text-sm text-slate-300 mb-2 max-w-lg">{a.bio}</p>
                <div className="flex gap-1.5 flex-wrap">
                  {a.specialties.map((s) => <span key={s} className="text-xs bg-control-bg border border-control-line px-2 py-0.5 rounded-full text-slate-400">{s}</span>)}
                  {a.certifications.map((c) => <span key={c} className="text-xs bg-control-bg border border-control-accent/30 text-control-accent px-2 py-0.5 rounded-full">{c}</span>)}
                </div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button className="bg-control-accent text-control-bg text-xs font-semibold px-3 py-1.5 rounded-md" onClick={() => decide(a.id, 'approve')}>Approve</button>
                <button className="border border-red-400 text-red-400 text-xs px-3 py-1.5 rounded-md" onClick={() => decide(a.id, 'reject')}>Reject</button>
              </div>
            </div>
          </div>
        ))}
        {apps.length === 0 && <p className="text-slate-500 text-sm">No pending applications.</p>}
      </div>
    </AdminLayout>
  );
}
