import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

export default function AdminUsers() {
  const { token, login } = useAuth();
  const nav = useNavigate();
  const [users, setUsers] = useState([]);
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');

  function load() {
    const params = new URLSearchParams();
    if (q) params.set('q', q);
    if (role) params.set('role', role);
    api.adminUsers(token, `?${params.toString()}`).then(setUsers);
  }
  useEffect(load, [token]);

  async function setStatus(id, status) {
    await api.adminSetUserStatus(token, id, status);
    load();
  }

  async function impersonate(id) {
    const { token: tok, user } = await api.adminImpersonate(token, id);
    login(tok, user);
    nav(user.role === 'trainee' ? '/trainee' : '/coach');
  }

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Users</h1>
      <p className="text-slate-500 text-sm mb-6">Search, suspend, or (audited) impersonate accounts.</p>

      <div className="flex gap-2 mb-5">
        <input
          className="bg-control-panel border border-control-line rounded-md px-3 py-2 text-sm text-slate-100 flex-1"
          placeholder="Search name or email…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && load()}
        />
        <select className="bg-control-panel border border-control-line rounded-md px-3 py-2 text-sm text-slate-100" value={role} onChange={(e) => { setRole(e.target.value); }}>
          <option value="">All roles</option>
          <option value="trainee">Trainee</option>
          <option value="coach">Coach</option>
          <option value="admin">Admin</option>
        </select>
        <button className="bg-control-accent text-control-bg font-semibold text-sm px-4 py-2 rounded-md" onClick={load}>Search</button>
      </div>

      <div className="border border-control-line rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-control-panel text-slate-400 text-xs uppercase">
            <tr><th className="text-left px-4 py-2">Name</th><th className="text-left px-4 py-2">Role</th><th className="text-left px-4 py-2">Status</th><th className="text-right px-4 py-2">Actions</th></tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-control-line">
                <td className="px-4 py-2.5"><div>{u.name}</div><div className="text-slate-500 text-xs">{u.email}</div></td>
                <td className="px-4 py-2.5 text-slate-300">{u.role}</td>
                <td className="px-4 py-2.5">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${u.status === 'active' ? 'bg-emerald-900 text-emerald-300' : 'bg-red-900 text-red-300'}`}>{u.status}</span>
                </td>
                <td className="px-4 py-2.5 text-right space-x-2">
                  {u.status === 'active' ? (
                    <button className="text-amber-400 text-xs" onClick={() => setStatus(u.id, 'suspended')}>Suspend</button>
                  ) : (
                    <button className="text-emerald-400 text-xs" onClick={() => setStatus(u.id, 'active')}>Reactivate</button>
                  )}
                  <button className="text-red-400 text-xs" onClick={() => setStatus(u.id, 'banned')}>Ban</button>
                  {u.role !== 'admin' && <button className="text-control-accent text-xs" onClick={() => impersonate(u.id)}>Impersonate</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
