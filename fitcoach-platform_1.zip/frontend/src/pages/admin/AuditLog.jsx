import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AdminLayout from '../../components/AdminLayout';

export default function AuditLog() {
  const { token } = useAuth();
  const [logs, setLogs] = useState([]);

  useEffect(() => { api.adminAuditLogs(token).then(setLogs); }, [token]);

  return (
    <AdminLayout>
      <h1 className="font-display font-bold text-2xl text-slate-100 mb-1">Audit log</h1>
      <p className="text-slate-500 text-sm mb-6">Immutable record of admin actions and health-data access. Superadmin only.</p>

      <div className="border border-control-line rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-control-panel text-slate-400 text-xs uppercase">
            <tr>
              <th className="text-left px-4 py-2">Time</th>
              <th className="text-left px-4 py-2">Actor</th>
              <th className="text-left px-4 py-2">Action</th>
              <th className="text-left px-4 py-2">Target</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l.id} className="border-t border-control-line">
                <td className="px-4 py-2.5 text-slate-500 text-xs">{l.created_at}</td>
                <td className="px-4 py-2.5 text-slate-400 text-xs font-mono">{l.actor_id}</td>
                <td className="px-4 py-2.5 text-slate-100">{l.action}</td>
                <td className="px-4 py-2.5 text-slate-500 text-xs">{l.target_type} · {l.target_id}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.length === 0 && <p className="text-slate-500 text-sm p-4">No audit entries yet.</p>}
      </div>
    </AdminLayout>
  );
}
