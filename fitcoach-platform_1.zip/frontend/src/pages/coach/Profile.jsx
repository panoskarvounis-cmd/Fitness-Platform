import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Field, Input, Button, ErrorBanner } from '../../components/ui';

export default function Profile() {
  const { token, user } = useAuth();
  const [form, setForm] = useState({ bio: '', specialties: '', hourly_rate: '', certifications: '' });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getCoachProfile(token, user.id).then((p) =>
      setForm({ bio: p.bio || '', specialties: p.specialties.join(', '), hourly_rate: p.hourly_rate, certifications: p.certifications.join(', ') })
    );
  }, [token, user.id]);

  async function save(e) {
    e.preventDefault();
    setError('');
    try {
      await api.updateCoachProfile(token, {
        bio: form.bio,
        specialties: form.specialties.split(',').map((s) => s.trim()).filter(Boolean),
        hourly_rate: Number(form.hourly_rate) || 0,
        certifications: form.certifications.split(',').map((s) => s.trim()).filter(Boolean),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) { setError(err.message); }
  }

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Your profile</h1>
      <p className="text-ink/50 mb-8">This is what trainees see in the coach directory.</p>
      <Card className="max-w-lg">
        <ErrorBanner message={error} />
        <form onSubmit={save}>
          <Field label="Bio"><textarea className="w-full rounded-lg border border-black/15 px-3 py-2 text-sm" rows={3} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></Field>
          <Field label="Specialties (comma-separated)" hint="e.g. strength, rehab, weight_loss"><Input value={form.specialties} onChange={(e) => setForm({ ...form, specialties: e.target.value })} /></Field>
          <Field label="Hourly rate (USD)"><Input type="number" value={form.hourly_rate} onChange={(e) => setForm({ ...form, hourly_rate: e.target.value })} /></Field>
          <Field label="Certifications (comma-separated)"><Input value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} /></Field>
          <Button type="submit" className="w-full">{saved ? 'Saved ✓' : 'Save profile'}</Button>
        </form>
      </Card>
    </AppLayout>
  );
}
