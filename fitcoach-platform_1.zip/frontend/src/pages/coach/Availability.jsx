import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Field, Input, Button, ErrorBanner } from '../../components/ui';

export default function Availability() {
  const { token, user } = useAuth();
  const [slots, setSlots] = useState([]);
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [error, setError] = useState('');

  function load() { api.getAvailability(token, user.id).then(setSlots); }
  useEffect(load, [token, user.id]);

  async function add(e) {
    e.preventDefault();
    setError('');
    try {
      await api.addAvailability(token, { start_time: start, end_time: end });
      setStart(''); setEnd('');
      load();
    } catch (err) { setError(err.message); }
  }

  async function remove(id) {
    await api.deleteAvailability(token, id);
    load();
  }

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Availability</h1>
      <p className="text-ink/50 mb-8">Open slots trainees can book directly.</p>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h2 className="font-display font-bold text-lg mb-4">Add a slot</h2>
          <ErrorBanner message={error} />
          <form onSubmit={add}>
            <Field label="Start time"><Input type="datetime-local" required value={start} onChange={(e) => setStart(e.target.value)} /></Field>
            <Field label="End time"><Input type="datetime-local" required value={end} onChange={(e) => setEnd(e.target.value)} /></Field>
            <Button type="submit" className="w-full">Add slot</Button>
          </form>
        </Card>
        <Card>
          <h2 className="font-display font-bold text-lg mb-4">Open slots</h2>
          <div className="space-y-2">
            {slots.map((s) => (
              <div key={s.id} className="flex items-center justify-between border border-black/10 rounded-lg px-3 py-2.5 text-sm">
                <span>{new Date(s.start_time).toLocaleString()}</span>
                <Button variant="danger" className="!text-xs !px-3 !py-1" onClick={() => remove(s.id)}>Remove</Button>
              </div>
            ))}
            {slots.length === 0 && <p className="text-sm text-ink/40">No open slots.</p>}
          </div>
        </Card>
      </div>
    </AppLayout>
  );
}
