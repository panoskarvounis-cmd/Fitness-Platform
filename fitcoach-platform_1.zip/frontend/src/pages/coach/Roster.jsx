import { useEffect, useState } from 'react';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Badge, Button, ErrorBanner } from '../../components/ui';

export default function Roster() {
  const { token } = useAuth();
  const [roster, setRoster] = useState([]);
  const [selected, setSelected] = useState(null);
  const [intake, setIntake] = useState(null);
  const [programs, setPrograms] = useState([]);
  const [suggestion, setSuggestion] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.getRoster(token).then(setRoster); }, [token]);

  async function openTrainee(t) {
    setSelected(t);
    setSuggestion(null);
    setError('');
    try {
      const [i, p] = await Promise.all([
        api.getHealthIntake(token, t.id).catch(() => null),
        api.getPrograms(token, t.id),
      ]);
      setIntake(i);
      setPrograms(p);
    } catch (err) {
      setError(err.message);
    }
  }

  async function suggest() {
    setError('');
    try {
      const rec = await api.suggestProgram(token, { trainee_id: selected.id });
      setSuggestion(rec);
      const p = await api.getPrograms(token, selected.id);
      setPrograms(p);
    } catch (err) {
      setError(err.message);
    }
  }

  async function approve(programId) {
    await api.approveProgram(token, programId);
    const p = await api.getPrograms(token, selected.id);
    setPrograms(p);
  }

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Roster</h1>
      <p className="text-ink/50 mb-8">Trainees currently assigned to you.</p>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-3">
          {roster.map((t) => (
            <Card key={t.id} className={`cursor-pointer ${selected?.id === t.id ? 'ring-2 ring-coral' : ''}`}>
              <div onClick={() => openTrainee(t)}>
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{t.name}</span>
                  <Badge tone={t.adherence < 50 ? 'bad' : 'good'}>{t.adherence}%</Badge>
                </div>
                {t.healthFlagPending && <Badge tone="warn" className="mt-2">health flag</Badge>}
              </div>
            </Card>
          ))}
          {roster.length === 0 && <p className="text-sm text-ink/40">No trainees yet — they'll appear once you build a program for them.</p>}
        </div>

        <div className="md:col-span-2">
          {!selected && <Card><p className="text-sm text-ink/40">Select a trainee to view their intake and plans.</p></Card>}
          {selected && (
            <div className="space-y-5">
              <ErrorBanner message={error} />
              <Card>
                <h2 className="font-display font-bold text-lg mb-3">{selected.name} — health & objectives intake</h2>
                {intake ? (
                  <div className="text-sm space-y-1">
                    {intake.parq_flag === 1 && (
                      <div className="bg-amber-50 text-amber-700 border border-amber-200 rounded-lg px-3 py-2 text-xs mb-2">
                        PAR-Q readiness screening flagged — review before approving intensity above light. This is a coaching
                        signal, not a medical diagnosis.
                      </div>
                    )}
                    <div><span className="text-ink/40">Age/sex:</span> {intake.answers.age} / {intake.answers.sex}</div>
                    <div><span className="text-ink/40">Injuries:</span> {intake.answers.injuries?.join(', ') || 'none reported'}</div>
                    <div><span className="text-ink/40">Chronic conditions:</span> {intake.answers.chronic_conditions?.join(', ') || 'none reported'}</div>
                    <div><span className="text-ink/40">Version:</span> {intake.version}</div>
                  </div>
                ) : <p className="text-sm text-ink/40">No intake on file.</p>}
              </Card>

              <Card>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-display font-bold text-lg">Programs</h2>
                  <Button className="!text-xs !px-3 !py-1.5" onClick={suggest} disabled={!intake}>Suggest draft plan</Button>
                </div>
                {suggestion && (
                  <div className="text-xs bg-ink/[0.03] rounded-lg p-3 mb-4">
                    <p className="font-semibold mb-1">Rules fired:</p>
                    <ul className="list-disc list-inside text-ink/60 space-y-0.5">
                      {suggestion.rulesFired.map((r, i) => <li key={i}>{r}</li>)}
                    </ul>
                  </div>
                )}
                <div className="space-y-2">
                  {programs.map((p) => (
                    <div key={p.id} className="border border-black/10 rounded-lg px-3 py-2.5">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-sm">{p.title}</span>
                        <div className="flex items-center gap-2">
                          <Badge tone={p.status === 'active' ? 'good' : 'warn'}>{p.status}</Badge>
                          {p.status === 'draft' && <Button className="!text-xs !px-3 !py-1" onClick={() => approve(p.id)}>Approve</Button>}
                        </div>
                      </div>
                    </div>
                  ))}
                  {programs.length === 0 && <p className="text-sm text-ink/40">No programs yet.</p>}
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
