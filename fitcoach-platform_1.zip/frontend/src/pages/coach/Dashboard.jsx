import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { api } from '../../api';
import AppLayout from '../../components/AppLayout';
import { Card, Badge, Button } from '../../components/ui';

export default function CoachDashboard() {
  const { token, user } = useAuth();
  const [roster, setRoster] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    api.getRoster(token).then(setRoster);
    api.getMyBookings(token).then(setBookings);
  }, [token]);

  const atRisk = roster.filter((r) => r.atRisk || r.healthFlagPending);

  return (
    <AppLayout>
      <h1 className="font-display font-bold text-3xl mb-1">Welcome, {user.name.split(' ')[0]}</h1>
      <p className="text-ink/50 mb-8">Your roster and upcoming sessions at a glance.</p>

      <div className="grid md:grid-cols-3 gap-5 mb-6">
        <Card><div className="text-ink/50 text-sm font-semibold mb-1">Active trainees</div><div className="font-display text-3xl font-bold">{roster.length}</div></Card>
        <Card><div className="text-ink/50 text-sm font-semibold mb-1">Needs attention</div><div className="font-display text-3xl font-bold text-coral">{atRisk.length}</div></Card>
        <Card><div className="text-ink/50 text-sm font-semibold mb-1">Upcoming sessions</div><div className="font-display text-3xl font-bold">{bookings.filter((b) => b.status === 'confirmed').length}</div></Card>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-lg">Trainees needing attention</h2>
          <Link to="/coach/roster"><Button variant="ghost" className="!text-xs !px-3 !py-1.5">Full roster</Button></Link>
        </div>
        {atRisk.length === 0 && <p className="text-sm text-ink/40">Everyone's on track.</p>}
        <div className="space-y-2">
          {atRisk.map((t) => (
            <div key={t.id} className="flex items-center justify-between border border-black/10 rounded-lg px-3 py-2.5 text-sm">
              <span className="font-semibold">{t.name}</span>
              <div className="flex gap-1.5">
                {t.healthFlagPending && <Badge tone="warn">health flag pending review</Badge>}
                {t.atRisk && <Badge tone="bad">{t.adherence}% adherence</Badge>}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </AppLayout>
  );
}
