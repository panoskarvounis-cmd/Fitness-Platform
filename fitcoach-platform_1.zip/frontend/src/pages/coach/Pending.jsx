import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../AuthContext';
import { Card, Button } from '../../components/ui';

export default function Pending() {
  const { logout } = useAuth();
  const nav = useNavigate();
  return (
    <div className="min-h-full bg-paper flex items-center justify-center px-6">
      <Card className="w-full max-w-md text-center">
        <h1 className="font-display font-bold text-2xl mb-2">Application received</h1>
        <p className="text-ink/60 text-sm mb-6">
          Thanks for applying to coach on FitCoach. Our admin team reviews certifications and
          credentials manually — you'll be notified once your account is approved and active.
        </p>
        <Button onClick={() => { logout(); nav('/login'); }}>Back to login</Button>
      </Card>
    </div>
  );
}
