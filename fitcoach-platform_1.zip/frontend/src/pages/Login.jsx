import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useAuth } from '../AuthContext';
import { Card, Field, Input, Button, ErrorBanner } from '../components/ui';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const nav = useNavigate();

  async function submit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token, user } = await api.login({ email, password });
      login(token, user);
      nav(user.role === 'admin' ? '/admin' : `/${user.role}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-full bg-paper flex items-center justify-center px-6">
      <Card className="w-full max-w-sm">
        <h1 className="font-display font-bold text-2xl mb-1">Welcome back</h1>
        <p className="text-ink/50 text-sm mb-6">Log in to FitCoach.</p>
        <ErrorBanner message={error} />
        <form onSubmit={submit}>
          <Field label="Email">
            <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password">
            <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <Button type="submit" disabled={loading} className="w-full mt-2">{loading ? 'Logging in…' : 'Log in'}</Button>
        </form>
        <p className="text-sm text-ink/50 mt-5">
          No account? <Link to="/register" className="text-coral font-semibold">Sign up</Link>
        </p>
        <div className="mt-6 pt-5 border-t border-black/10 text-xs text-ink/40 space-y-1">
          <p className="font-semibold text-ink/60">Demo logins</p>
          <p>Admin — admin@fitcoach.dev / admin123</p>
          <p>Coach — marcus@fitcoach.dev / coach123</p>
          <p>Trainee — sam@fitcoach.dev / trainee123</p>
        </div>
      </Card>
    </div>
  );
}
