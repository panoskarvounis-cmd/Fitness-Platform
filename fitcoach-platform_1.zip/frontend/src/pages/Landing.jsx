import { Link } from 'react-router-dom';
import { Button } from '../components/ui';

export default function Landing() {
  return (
    <div className="min-h-full bg-ink text-paper">
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-6 py-6">
        <span className="font-display font-bold text-xl tracking-tight">FitCoach</span>
        <div className="flex gap-3">
          <Link to="/login"><Button variant="ghost" className="!text-paper !border-paper/20">Log in</Button></Link>
          <Link to="/register"><Button variant="primary">Get started</Button></Link>
        </div>
      </nav>

      <header className="max-w-6xl mx-auto px-6 pt-16 pb-24 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <div className="font-mono text-coral text-sm mb-4 tracking-widest uppercase">Intake → Plan → Progress</div>
          <h1 className="font-display text-5xl md:text-6xl font-bold leading-[1.05] mb-6">
            A coach who sees your <span className="text-coral">whole</span> training picture.
          </h1>
          <p className="text-paper/70 text-lg mb-8 max-w-md">
            Tell us your goals and health history once. We match you with a certified coach,
            draft a starting plan for their review, and track every rep against your KPIs —
            so progress is a number, not a guess.
          </p>
          <div className="flex gap-3">
            <Link to="/register"><Button variant="primary" className="!px-7 !py-3 !text-base">Find a coach</Button></Link>
            <Link to="/register?role=coach"><Button variant="ghost" className="!text-paper !border-paper/20 !px-7 !py-3 !text-base">I'm a coach</Button></Link>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            ['92 → 89.5kg', 'Weight trend, 4 weeks'],
            ['20%', 'Adherence this cycle'],
            ['Draft', 'Plan awaiting coach sign-off'],
            ['PAR-Q clear', 'Readiness screening'],
          ].map(([big, small]) => (
            <div key={small} className="bg-white/5 border border-white/10 rounded-2xl p-5">
              <div className="font-display text-2xl font-bold mb-1">{big}</div>
              <div className="text-paper/50 text-sm">{small}</div>
            </div>
          ))}
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 pb-24 grid md:grid-cols-3 gap-6">
        {[
          ['Trainees', 'Complete a health & goals intake, browse coaches, book sessions, and log every workout against your plan.'],
          ['Coaches', 'Manage your calendar, review AI-drafted plan suggestions, and keep an eye on adherence across your roster.'],
          ['Admins', 'A separate, audited back office for approvals, catalog, moderation, payouts, and platform analytics.'],
        ].map(([title, body], i) => (
          <div key={title} className="border border-white/10 rounded-2xl p-6">
            <div className="font-mono text-coral text-xs mb-3">0{i + 1}</div>
            <h3 className="font-display font-bold text-lg mb-2">{title}</h3>
            <p className="text-paper/60 text-sm leading-relaxed">{body}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
