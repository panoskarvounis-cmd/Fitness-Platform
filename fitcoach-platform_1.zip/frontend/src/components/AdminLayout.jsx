import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

const links = [
  ['/admin', 'Dashboard'],
  ['/admin/users', 'Users'],
  ['/admin/applications', 'Coach applications'],
  ['/admin/moderation', 'Moderation'],
  ['/admin/financials', 'Financials'],
  ['/admin/audit', 'Audit log'],
];

export default function AdminLayout({ children }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  return (
    <div className="min-h-full bg-control-bg text-slate-100 font-mono">
      <div className="flex">
        <aside className="w-60 shrink-0 border-r border-control-line min-h-screen p-5 hidden md:block">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-control-accent animate-pulse" />
            <span className="font-display font-bold text-sm tracking-widest uppercase text-control-accent">Admin</span>
          </div>
          <p className="text-xs text-slate-500 mb-8">FitCoach back office</p>
          <nav className="space-y-1">
            {links.map(([to, label]) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/admin'}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-md text-sm transition ${isActive ? 'bg-control-panel text-control-accent' : 'text-slate-400 hover:bg-control-panel/60'}`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>
          <div className="mt-10 pt-5 border-t border-control-line text-xs text-slate-500">
            <p>{user?.name}</p>
            <p className="text-slate-600">scope: {user?.admin_scope}</p>
            <button className="mt-3 text-control-accent" onClick={() => { logout(); nav('/login'); }}>Log out →</button>
          </div>
        </aside>
        <main className="flex-1 p-8 max-w-5xl">{children}</main>
      </div>
    </div>
  );
}
