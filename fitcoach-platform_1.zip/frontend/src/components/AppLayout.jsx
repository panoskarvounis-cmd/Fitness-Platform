import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { Button } from './ui';

export default function AppLayout({ children }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  const links =
    user?.role === 'trainee'
      ? [
          ['/trainee', 'Dashboard'],
          ['/trainee/coaches', 'Find a coach'],
          ['/trainee/plan', 'My plan'],
        ]
      : [
          ['/coach', 'Dashboard'],
          ['/coach/roster', 'Roster'],
          ['/coach/availability', 'Availability'],
          ['/coach/profile', 'Profile'],
        ];

  return (
    <div className="min-h-full bg-paper">
      <nav className="border-b border-black/10 bg-paper sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-8">
            <span className="font-display font-bold text-lg">FitCoach</span>
            <div className="hidden sm:flex gap-1">
              {links.map(([to, label]) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/trainee' || to === '/coach'}
                  className={({ isActive }) =>
                    `px-3 py-1.5 rounded-full text-sm font-medium transition ${isActive ? 'bg-ink text-paper' : 'text-ink/60 hover:bg-ink/5'}`
                  }
                >
                  {label}
                </NavLink>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-ink/50 hidden sm:inline">{user?.name}</span>
            <Button variant="ghost" className="!px-4 !py-1.5 !text-xs" onClick={() => { logout(); nav('/login'); }}>
              Log out
            </Button>
          </div>
        </div>
      </nav>
      <main className="max-w-6xl mx-auto px-6 py-8">{children}</main>
    </div>
  );
}
