export function Card({ children, className = '' }) {
  return <div className={`bg-white border border-black/10 rounded-2xl p-6 ${className}`}>{children}</div>;
}

export function Button({ children, variant = 'primary', className = '', ...props }) {
  const base = 'inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 font-semibold text-sm transition disabled:opacity-40 disabled:cursor-not-allowed';
  const variants = {
    primary: 'bg-coral text-white hover:bg-coral-dark',
    ghost: 'bg-transparent text-ink hover:bg-ink/5 border border-ink/15',
    dark: 'bg-ink text-paper hover:bg-black',
    danger: 'bg-red-600 text-white hover:bg-red-700',
    control: 'bg-control-accent text-control-bg hover:brightness-110',
  };
  return (
    <button className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}

export function Field({ label, children, hint }) {
  return (
    <label className="block mb-4">
      <span className="block text-sm font-semibold text-ink/70 mb-1">{label}</span>
      {children}
      {hint && <span className="block text-xs text-ink/40 mt-1">{hint}</span>}
    </label>
  );
}

export function Input(props) {
  return (
    <input
      {...props}
      className={`w-full rounded-lg border border-black/15 px-3 py-2 text-sm focus:border-coral outline-none ${props.className || ''}`}
    />
  );
}

export function Select({ children, ...props }) {
  return (
    <select {...props} className="w-full rounded-lg border border-black/15 px-3 py-2 text-sm focus:border-coral outline-none bg-white">
      {children}
    </select>
  );
}

export function Badge({ children, tone = 'default' }) {
  const tones = {
    default: 'bg-ink/8 text-ink',
    good: 'bg-moss/15 text-moss',
    warn: 'bg-amber-100 text-amber-700',
    bad: 'bg-red-100 text-red-700',
  };
  return <span className={`inline-block text-xs font-semibold px-2.5 py-1 rounded-full ${tones[tone]}`}>{children}</span>;
}

export function Bar({ pct, tone = 'coral' }) {
  const colors = { coral: 'bg-coral', moss: 'bg-moss', sky: 'bg-control-accent' };
  return (
    <div className="w-full h-2.5 rounded-full bg-ink/8 overflow-hidden">
      <div className={`h-full ${colors[tone]} rounded-full transition-all`} style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} />
    </div>
  );
}

export function ErrorBanner({ message }) {
  if (!message) return null;
  return <div className="mb-4 text-sm bg-red-50 text-red-700 border border-red-200 rounded-lg px-4 py-2.5">{message}</div>;
}
