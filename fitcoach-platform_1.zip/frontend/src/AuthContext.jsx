import { createContext, useContext, useState, useCallback } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => sessionStorage.getItem('fc_token'));
  const [user, setUser] = useState(() => {
    const raw = sessionStorage.getItem('fc_user');
    return raw ? JSON.parse(raw) : null;
  });

  const login = useCallback((tok, usr) => {
    setToken(tok);
    setUser(usr);
    sessionStorage.setItem('fc_token', tok);
    sessionStorage.setItem('fc_user', JSON.stringify(usr));
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    sessionStorage.removeItem('fc_token');
    sessionStorage.removeItem('fc_user');
  }, []);

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
