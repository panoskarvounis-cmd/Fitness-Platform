const BASE = 'http://localhost:4000/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  register: (body) => request('/auth/register', { method: 'POST', body }),
  login: (body) => request('/auth/login', { method: 'POST', body }),
  me: (token) => request('/auth/me', { token }),

  submitHealthIntake: (token, answers) => request('/trainee/health-intake', { method: 'POST', body: { answers }, token }),
  getHealthIntake: (token, traineeId) => request(`/trainee/health-intake/${traineeId}/latest`, { token }),
  createObjective: (token, body) => request('/trainee/objectives', { method: 'POST', body, token }),
  getObjectives: (token, traineeId) => request(`/trainee/objectives/${traineeId}`, { token }),
  addBodyMetric: (token, body) => request('/trainee/body-metrics', { method: 'POST', body, token }),
  getBodyMetrics: (token, traineeId) => request(`/trainee/body-metrics/${traineeId}`, { token }),
  getPrograms: (token, traineeId) => request(`/trainee/programs/${traineeId}`, { token }),
  logWorkout: (token, body) => request('/trainee/workout-logs', { method: 'POST', body, token }),
  getKpi: (token, traineeId) => request(`/trainee/kpi/${traineeId}`, { token }),

  getDirectory: (token, params = '') => request(`/coach/directory${params}`, { token }),
  getCoachProfile: (token, id) => request(`/coach/profile/${id}`, { token }),
  updateCoachProfile: (token, body) => request('/coach/profile', { method: 'PUT', body, token }),
  addAvailability: (token, body) => request('/coach/availability', { method: 'POST', body, token }),
  getAvailability: (token, coachId) => request(`/coach/availability/${coachId}`, { token }),
  deleteAvailability: (token, id) => request(`/coach/availability/${id}`, { method: 'DELETE', token }),
  getRoster: (token) => request('/coach/roster', { token }),
  getExercises: (token) => request('/coach/exercises', { token }),
  suggestProgram: (token, body) => request('/coach/programs/suggest', { method: 'POST', body, token }),
  createProgram: (token, body) => request('/coach/programs', { method: 'POST', body, token }),
  approveProgram: (token, id) => request(`/coach/programs/${id}/approve`, { method: 'PUT', token }),

  createBooking: (token, body) => request('/bookings', { method: 'POST', body, token }),
  getMyBookings: (token) => request('/bookings/mine', { token }),
  updateBookingStatus: (token, id, status) => request(`/bookings/${id}/status`, { method: 'PUT', body: { status }, token }),

  createReview: (token, body) => request('/reviews', { method: 'POST', body, token }),
  getReviews: (token, coachId) => request(`/reviews/${coachId}`, { token }),
  sendMessage: (token, body) => request('/messages', { method: 'POST', body, token }),
  getMessages: (token, counterpartId) => request(`/messages/${counterpartId}`, { token }),

  adminDashboard: (token) => request('/admin/dashboard', { token }),
  adminUsers: (token, params = '') => request(`/admin/users${params}`, { token }),
  adminSetUserStatus: (token, id, status) => request(`/admin/users/${id}/status`, { method: 'PUT', body: { status }, token }),
  adminResetPassword: (token, id) => request(`/admin/users/${id}/reset-password`, { method: 'POST', token }),
  adminImpersonate: (token, id) => request(`/admin/users/${id}/impersonate`, { method: 'POST', token }),
  adminCoachApplications: (token) => request('/admin/coach-applications', { token }),
  adminReviewApplication: (token, userId, decision, notes) =>
    request(`/admin/coach-applications/${userId}`, { method: 'PUT', body: { decision, notes }, token }),
  adminCatalog: (token) => request('/admin/catalog', { token }),
  adminPendingReviews: (token) => request('/admin/moderation/reviews', { token }),
  adminModerateReview: (token, id, decision) =>
    request(`/admin/moderation/reviews/${id}`, { method: 'PUT', body: { decision }, token }),
  adminFinancials: (token) => request('/admin/financials', { token }),
  adminAuditLogs: (token) => request('/admin/audit-logs', { token }),
};
