import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

export function Protected({ roles, children }) {
  const { user, token } = useAuth();
  if (!token || !user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) {
    return <Navigate to={user.role === 'admin' ? '/admin' : `/${user.role}`} replace />;
  }
  return children;
}
