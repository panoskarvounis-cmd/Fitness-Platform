/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#14171A',
        paper: '#F7F5F0',
        coral: {
          DEFAULT: '#FF5A3C',
          dark: '#E1441F',
        },
        moss: '#2FA88A',
        sand: '#E8E2D4',
        control: {
          bg: '#0F172A',
          panel: '#141F38',
          accent: '#38BDF8',
          line: '#223052',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
    },
  },
  plugins: [],
};
