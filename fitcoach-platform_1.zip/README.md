# FitCoach

A working implementation of the FitCoach platform spec: trainees, coaches, and
admins in one app, built around the intake → match → plan → track loop.

This is a **local-dev-ready MVP** covering Phases 1–3 of the spec in full and
Phase 4 in stubbed form (payments are mocked, no real Stripe/S3 wired up yet —
see "What's stubbed" below).

## Stack

- **Backend**: Node.js + Express + SQLite (via `better-sqlite3`), JWT auth, RBAC middleware
- **Frontend**: React (Vite) + TailwindCSS + React Router + Recharts

SQLite is used in place of the spec's suggested Postgres/Redis so the whole
thing runs with zero external services — swap in Postgres later by replacing
`backend/src/db/db.js` with a Postgres client; the SQL is close to standard.

## Quick start

You need Node.js 18+ installed.

```bash
# 1. Backend
cd backend
npm install
npm run seed      # creates data/fitcoach.sqlite and demo accounts
npm start         # runs on http://localhost:4000

# 2. Frontend (in a second terminal)
cd frontend
npm install
npm run dev        # runs on http://localhost:5173
```

Open http://localhost:5173.

## Demo logins

| Role    | Email                  | Password    | Notes                                   |
|---------|------------------------|-------------|------------------------------------------|
| Admin   | admin@fitcoach.dev     | admin123    | superadmin scope                         |
| Coach   | marcus@fitcoach.dev    | coach123    | approved, has a trainee assigned         |
| Coach   | priya@fitcoach.dev     | coach123    | approved                                 |
| Coach   | diego@fitcoach.dev     | coach123    | **pending** — approve via /admin to test |
| Trainee | sam@fitcoach.dev       | trainee123  | PAR-Q flagged, has an active program     |
| Trainee | jordan@fitcoach.dev    | trainee123  | fresh account, no program yet            |

To reset all data: delete `backend/data/fitcoach.sqlite*` and re-run `npm run seed`.

## What's implemented

- **Auth & RBAC**: JWT auth, role selection at signup, coach accounts require
  admin approval before going active. RBAC is centralized in middleware
  (`backend/src/middleware/auth.js`), matching the permissions matrix in §3 of
  the spec — never enforced ad hoc per endpoint.
- **Health & objectives intake**: versioned questionnaire with a PAR-Q-style
  readiness screen. Only the trainee, their assigned coach, and admins can view
  it, and every view/submission is written to an immutable audit log.
- **Coach discovery & booking**: directory with specialty/price filtering,
  live availability, instant booking with slot-conflict checks, mocked payment
  capture.
- **Recommendation engine**: rules-based only (`backend/src/utils/recommendation.js`),
  never a diagnosis. Every suggestion is stored as a `draft` program with the
  rules that produced it, and must be explicitly approved by the assigned
  coach before a trainee sees it as active — including PAR-Q-flagged trainees.
- **Progress & KPIs**: adherence rate, volume trend, goal-progress bar, at-risk
  flagging on the coach roster view.
- **Admin back office**: separate route tree and a deliberately distinct visual
  theme, dashboard, user management (suspend/ban/reset/audited impersonation),
  coach application queue, review moderation, financials, and an audit log
  viewer (superadmin-scoped).

## What's stubbed (per §10.10 of the spec — flagged rather than faked)

- **Payments**: bookings write a `payments` row with a `mock_stub_*` provider
  ref instead of calling Stripe. Wire up Stripe Connect in
  `backend/src/routes/bookings.js` when real keys are available.
- **File storage**: certification uploads and progress photos aren't wired to
  S3 — the coach-profile certifications field is a plain text list for now.
- **Password reset / email**: `admin/users/:id/reset-password` logs an audited
  action but doesn't send an email.
- **Wearables integration**: not built (explicitly phase 2+ in the spec).

## Project layout

```
backend/
  src/
    db/            SQLite schema + seed data
    middleware/     JWT auth + centralized RBAC + audit logging
    routes/         auth, trainee, coach, bookings, social, admin
    utils/          rules-based recommendation engine
frontend/
  src/
    pages/trainee/  onboarding, dashboard, coach directory, plan/logging
    pages/coach/    dashboard, roster, availability, profile
    pages/admin/    dashboard, users, applications, moderation, financials, audit
    components/     shared UI kit + layouts (admin uses a distinct dark theme)
```

## Notes on scope vs. the full spec

This build covers the core value loop end-to-end so it's fully demoable. Not
yet built: recurring bookings/waitlists, cancellation-fee policy engine,
in-app messaging UI (the API exists in `routes/social.js`), review submission
UI on the trainee side, and PDF progress-report export. These are
straightforward additions on top of the existing data model and routes if you
want to keep building — the `programs`, `bookings`, and `kpi_snapshots`-style
endpoints are already shaped to support them.
