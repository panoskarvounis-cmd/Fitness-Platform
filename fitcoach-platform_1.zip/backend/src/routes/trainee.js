import express from 'express';
import { v4 as uuid } from 'uuid';
import db from '../db/db.js';
import { requireAuth, requireRole, audit } from '../middleware/auth.js';
import { evaluateParQ } from '../utils/recommendation.js';

const router = express.Router();

// Only the trainee themself, their assigned coach, or admin (support/audit) may view intake.
function canViewTraineeHealthData(user, traineeId) {
  if (user.role === 'admin') return true;
  if (user.id === traineeId) return true;
  if (user.role === 'coach') {
    const assigned = db
      .prepare(`SELECT 1 FROM programs WHERE coach_id = ? AND trainee_id = ? LIMIT 1`)
      .get(user.id, traineeId);
    return !!assigned;
  }
  return false;
}

// --- Health & Objectives Intake ---
router.post('/health-intake', requireAuth, requireRole('trainee'), (req, res) => {
  const { answers } = req.body;
  if (!answers || typeof answers !== 'object') return res.status(400).json({ error: 'answers object is required' });

  const lastVersion = db
    .prepare(`SELECT MAX(version) as v FROM health_intakes WHERE trainee_id = ?`)
    .get(req.user.id).v || 0;

  const parqFlag = evaluateParQ(answers);
  const id = uuid();
  db.prepare(
    `INSERT INTO health_intakes (id, trainee_id, version, answers_json, parq_flag) VALUES (?,?,?,?,?)`
  ).run(id, req.user.id, lastVersion + 1, JSON.stringify(answers), parqFlag ? 1 : 0);

  audit(req.user.id, 'health_intake_submitted', 'health_intake', id, { version: lastVersion + 1, parqFlag });
  res.status(201).json({ id, version: lastVersion + 1, parqFlag });
});

router.get('/health-intake/:traineeId/latest', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized to view this health record' });
  }
  const intake = db
    .prepare(`SELECT * FROM health_intakes WHERE trainee_id = ? ORDER BY version DESC LIMIT 1`)
    .get(req.params.traineeId);
  if (!intake) return res.status(404).json({ error: 'No health intake on file yet' });

  audit(req.user.id, 'health_intake_viewed', 'health_intake', intake.id, { traineeId: req.params.traineeId });
  res.json({ ...intake, answers: JSON.parse(intake.answers_json) });
});

// --- Objectives ---
router.post('/objectives', requireAuth, requireRole('trainee'), (req, res) => {
  const { type, target_value, target_date } = req.body;
  const id = uuid();
  db.prepare(
    `INSERT INTO objectives (id, trainee_id, type, target_value, target_date) VALUES (?,?,?,?,?)`
  ).run(id, req.user.id, type, target_value || null, target_date || null);
  res.status(201).json({ id });
});

router.get('/objectives/:traineeId', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const rows = db.prepare(`SELECT * FROM objectives WHERE trainee_id = ?`).all(req.params.traineeId);
  res.json(rows);
});

// --- Body metrics ---
router.post('/body-metrics', requireAuth, requireRole('trainee'), (req, res) => {
  const { weight, body_fat_pct, measurements } = req.body;
  const id = uuid();
  db.prepare(
    `INSERT INTO body_metrics (id, trainee_id, weight, body_fat_pct, measurements_json) VALUES (?,?,?,?,?)`
  ).run(id, req.user.id, weight ?? null, body_fat_pct ?? null, JSON.stringify(measurements || {}));
  res.status(201).json({ id });
});

router.get('/body-metrics/:traineeId', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const rows = db
    .prepare(`SELECT * FROM body_metrics WHERE trainee_id = ? ORDER BY date ASC`)
    .all(req.params.traineeId);
  res.json(rows);
});

// --- Active program view (trainee-facing) ---
router.get('/programs/:traineeId', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const programs = db
    .prepare(`SELECT * FROM programs WHERE trainee_id = ? ORDER BY created_at DESC`)
    .all(req.params.traineeId);
  const withItems = programs.map((p) => ({
    ...p,
    rules: p.rules_json ? JSON.parse(p.rules_json) : null,
    items: db
      .prepare(
        `SELECT pi.*, e.name as exercise_name, e.muscle_groups_json, e.contraindication_tags_json
         FROM program_items pi JOIN exercise_library e ON e.id = pi.exercise_id
         WHERE pi.program_id = ? ORDER BY pi.day_index ASC`
      )
      .all(p.id),
  }));
  res.json(withItems);
});

// --- Workout logging ---
router.post('/workout-logs', requireAuth, requireRole('trainee'), (req, res) => {
  const { program_item_id, actual_sets, actual_reps, actual_weight, rpe } = req.body;
  const id = uuid();
  db.prepare(
    `INSERT INTO workout_logs (id, trainee_id, program_item_id, actual_sets, actual_reps, actual_weight, rpe)
     VALUES (?,?,?,?,?,?,?)`
  ).run(id, req.user.id, program_item_id, actual_sets ?? null, actual_reps ?? null, actual_weight ?? null, rpe ?? null);
  res.status(201).json({ id });
});

router.get('/workout-logs/:traineeId', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const rows = db
    .prepare(`SELECT * FROM workout_logs WHERE trainee_id = ? ORDER BY date DESC`)
    .all(req.params.traineeId);
  res.json(rows);
});

// --- KPI dashboard (computed on the fly for simplicity) ---
router.get('/kpi/:traineeId', requireAuth, (req, res) => {
  if (!canViewTraineeHealthData(req.user, req.params.traineeId)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const traineeId = req.params.traineeId;

  const totalItems = db
    .prepare(
      `SELECT COUNT(*) as c FROM program_items pi
       JOIN programs p ON p.id = pi.program_id
       WHERE p.trainee_id = ? AND p.status = 'active'`
    )
    .get(traineeId).c;
  const loggedItems = db
    .prepare(`SELECT COUNT(DISTINCT program_item_id) as c FROM workout_logs WHERE trainee_id = ?`)
    .get(traineeId).c;
  const adherenceRate = totalItems > 0 ? Math.min(100, Math.round((loggedItems / totalItems) * 100)) : 0;

  const volumeRows = db
    .prepare(`SELECT date, actual_sets, actual_reps, actual_weight FROM workout_logs WHERE trainee_id = ? ORDER BY date ASC`)
    .all(traineeId);
  const volumeTrend = volumeRows.map((r) => ({
    date: r.date,
    volume: (r.actual_sets || 0) * (r.actual_reps || 0) * (r.actual_weight || 0),
  }));

  const objectives = db.prepare(`SELECT * FROM objectives WHERE trainee_id = ?`).all(traineeId);
  const metrics = db
    .prepare(`SELECT * FROM body_metrics WHERE trainee_id = ? ORDER BY date ASC`)
    .all(traineeId);
  const latestWeight = metrics.length ? metrics[metrics.length - 1].weight : null;
  const startWeight = metrics.length ? metrics[0].weight : null;

  const goalProgress = objectives
    .filter((o) => o.type === 'weight_loss' || o.type === 'muscle_gain')
    .map((o) => {
      if (latestWeight == null || startWeight == null || o.target_value == null) return { objective: o, progressPct: null };
      const totalDelta = o.target_value - startWeight;
      const currentDelta = latestWeight - startWeight;
      const pct = totalDelta !== 0 ? Math.round((currentDelta / totalDelta) * 100) : 0;
      return { objective: o, progressPct: Math.max(0, Math.min(100, pct)) };
    });

  const atRisk = adherenceRate < 50;

  res.json({ adherenceRate, volumeTrend, goalProgress, atRisk, latestWeight, startWeight });
});

export default router;
