import express from 'express';
import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import db from '../db/db.js';
import { signToken, requireAuth, audit } from '../middleware/auth.js';

const router = express.Router();

router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: 'name, email, password, and role are required' });
  }
  if (!['trainee', 'coach'].includes(role)) {
    return res.status(400).json({ error: 'role must be trainee or coach at signup' });
  }
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ error: 'An account with that email already exists' });

  const id = uuid();
  const hash = bcrypt.hashSync(password, 10);
  // Coach accounts require admin approval before becoming active (§4.1)
  const status = role === 'coach' ? 'pending' : 'active';

  db.prepare(
    `INSERT INTO users (id, role, name, email, password_hash, status) VALUES (?,?,?,?,?,?)`
  ).run(id, role, name, email, hash, status);

  if (role === 'trainee') {
    db.prepare(`INSERT INTO trainee_profiles (user_id) VALUES (?)`).run(id);
  } else {
    db.prepare(`INSERT INTO coach_profiles (user_id) VALUES (?)`).run(id);
  }

  audit(id, 'user_registered', 'user', id, { role });

  const user = { id, role, name, email, status };
  res.status(201).json({ token: signToken(user), user });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  if (user.status === 'banned') return res.status(403).json({ error: 'This account has been banned' });
  if (user.status === 'suspended') return res.status(403).json({ error: 'This account is suspended' });

  audit(user.id, 'user_login', 'user', user.id, {});
  const safe = { id: user.id, role: user.role, name: user.name, email: user.email, status: user.status, admin_scope: user.admin_scope };
  res.json({ token: signToken(safe), user: safe });
});

router.get('/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT id, role, name, email, status, admin_scope, mfa_enabled FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user });
});

export default router;
