import express from 'express';
import { v4 as uuid } from 'uuid';
import db from '../db/db.js';
import { requireAuth, requireRole, audit } from '../middleware/auth.js';
import { buildRecommendation } from '../utils/recommendation.js';

const router = express.Router();

// --- Public-ish coach directory (any authenticated user can browse) ---
router.get('/directory', requireAuth, (req, res) => {
  const { specialty, maxPrice } = req.query;
  let rows = db
    .prepare(
      `SELECT u.id, u.name, cp.bio, cp.specialties_json, cp.hourly_rate, cp.certifications_json, cp.verification_status
       FROM users u JOIN coach_profiles cp ON cp.user_id = u.id
       WHERE u.role = 'coach' AND u.status = 'active' AND cp.verification_status = 'approved'`
    )
    .all()
    .map((r) => ({ ...r, specialties: JSON.parse(r.specialties_json), certifications: JSON.parse(r.certifications_json) }));

  if (specialty) rows = rows.filter((r) => r.specialties.includes(specialty));
  if (maxPrice) rows = rows.filter((r) => r.hourly_rate <= Number(maxPrice));

  res.json(rows);
});

router.get('/profile/:id', requireAuth, (req, res) => {
  const row = db
    .prepare(
      `SELECT u.id, u.name, cp.* FROM users u JOIN coach_profiles cp ON cp.user_id = u.id WHERE u.id = ?`
    )
    .get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Coach not found' });
  res.json({ ...row, specialties: JSON.parse(row.specialties_json), certifications: JSON.parse(row.certifications_json) });
});

router.put('/profile', requireAuth, requireRole('coach'), (req, res) => {
  const { bio, specialties, hourly_rate, certifications } = req.body;
  db.prepare(
    `UPDATE coach_profiles SET bio = ?, specialties_json = ?, hourly_rate = ?, certifications_json = ? WHERE user_id = ?`
  ).run(bio || '', JSON.stringify(specialties || []), hourly_rate || 0, JSON.stringify(certifications || []), req.user.id);
  res.json({ ok: true });
});

// --- Availability ---
router.post('/availability', requireAuth, requireRole('coach'), (req, res) => {
  const { start_time, end_time } = req.body;
  if (!start_time || !end_time) return res.status(400).json({ error: 'start_time and end_time are required' });
  const id = uuid();
  db.prepare(`INSERT INTO availability_slots (id, coach_id, start_time, end_time) VALUES (?,?,?,?)`).run(
    id, req.user.id, start_time, end_time
  );
  res.status(201).json({ id });
});

router.get('/availability/:coachId', requireAuth, (req, res) => {
  const rows = db
    .prepare(`SELECT * FROM availability_slots WHERE coach_id = ? AND is_booked = 0 ORDER BY start_time ASC`)
    .all(req.params.coachId);
  res.json(rows);
});

router.delete('/availability/:id', requireAuth, requireRole('coach'), (req, res) => {
  const slot = db.prepare(`SELECT * FROM availability_slots WHERE id = ?`).get(req.params.id);
  if (!slot || slot.coach_id !== req.user.id) return res.status(404).json({ error: 'Slot not found' });
  db.prepare(`DELETE FROM availability_slots WHERE id = ?`).run(req.params.id);
  res.json({ ok: true });
});

// --- Roster (their trainees, via programs) ---
router.get('/roster', requireAuth, requireRole('coach'), (req, res) => {
  const trainees = db
    .prepare(
      `SELECT DISTINCT u.id, u.name, u.email FROM users u
       JOIN programs p ON p.trainee_id = u.id WHERE p.coach_id = ?`
    )
    .all(req.user.id);

  const roster = trainees.map((t) => {
    const latestIntake = db
      .prepare(`SELECT parq_flag FROM health_intakes WHERE trainee_id = ? ORDER BY version DESC LIMIT 1`)
      .get(t.id);
    const totalItems = db
      .prepare(
        `SELECT COUNT(*) as c FROM program_items pi JOIN programs p ON p.id = pi.program_id
         WHERE p.trainee_id = ? AND p.coach_id = ? AND p.status='active'`
      )
      .get(t.id, req.user.id).c;
    const loggedItems = db
      .prepare(`SELECT COUNT(DISTINCT program_item_id) as c FROM workout_logs WHERE trainee_id = ?`)
      .get(t.id).c;
    const adherence = totalItems > 0 ? Math.round((loggedItems / totalItems) * 100) : 0;
    return {
      ...t,
      adherence,
      healthFlagPending: !!latestIntake?.parq_flag,
      atRisk: adherence < 50,
    };
  });
  res.json(roster);
});

// --- Exercise library ---
router.get('/exercises', requireAuth, (req, res) => {
  res.json(db.prepare(`SELECT * FROM exercise_library`).all().map((e) => ({
    ...e,
    muscle_groups: JSON.parse(e.muscle_groups_json),
    contraindication_tags: JSON.parse(e.contraindication_tags_json),
  })));
});

// --- AI-suggested draft program (rules-based, coach must approve) ---
router.post('/programs/suggest', requireAuth, requireRole('coach'), (req, res) => {
  const { trainee_id } = req.body;
  const intake = db
    .prepare(`SELECT * FROM health_intakes WHERE trainee_id = ? ORDER BY version DESC LIMIT 1`)
    .get(trainee_id);
  if (!intake) return res.status(404).json({ error: 'Trainee has no health intake on file yet' });

  const answers = JSON.parse(intake.answers_json);
  const objective = db.prepare(`SELECT * FROM objectives WHERE trainee_id = ? ORDER BY rowid DESC LIMIT 1`).get(trainee_id);
  const traineeProfile = db.prepare(`SELECT * FROM trainee_profiles WHERE user_id = ?`).get(trainee_id);

  const rec = buildRecommendation(answers, objective?.type, traineeProfile?.activity_level);

  const id = uuid();
  db.prepare(
    `INSERT INTO programs (id, coach_id, trainee_id, title, source, status, rules_json)
     VALUES (?,?,?,?,?,?,?)`
  ).run(
    id,
    req.user.id,
    trainee_id,
    `AI-suggested draft: ${rec.draft.split} (${rec.draft.frequencyPerWeek}x/week)`,
    'ai_suggested',
    'draft',
    JSON.stringify(rec)
  );

  audit(req.user.id, 'program_suggested', 'program', id, { trainee_id, parqFlag: rec.parqFlag });
  res.status(201).json({ id, ...rec });
});

// --- Program CRUD ---
router.post('/programs', requireAuth, requireRole('coach'), (req, res) => {
  const { trainee_id, title, items, source } = req.body;
  const id = uuid();
  db.prepare(
    `INSERT INTO programs (id, coach_id, trainee_id, title, source, status) VALUES (?,?,?,?,?, 'draft')`
  ).run(id, req.user.id, trainee_id, title, source || 'custom');

  for (const item of items || []) {
    db.prepare(
      `INSERT INTO program_items (id, program_id, day_index, exercise_id, sets, reps, weight, notes)
       VALUES (?,?,?,?,?,?,?,?)`
    ).run(uuid(), id, item.day_index, item.exercise_id, item.sets, item.reps, item.weight || null, item.notes || '');
  }
  audit(req.user.id, 'program_created', 'program', id, { trainee_id });
  res.status(201).json({ id });
});

router.put('/programs/:id/approve', requireAuth, requireRole('coach'), (req, res) => {
  const program = db.prepare(`SELECT * FROM programs WHERE id = ?`).get(req.params.id);
  if (!program || program.coach_id !== req.user.id) return res.status(404).json({ error: 'Program not found' });

  // Never push an unreviewed plan live for PAR-Q positive trainees without explicit coach approval.
  db.prepare(`UPDATE programs SET status = 'active' WHERE id = ?`).run(req.params.id);
  audit(req.user.id, 'program_approved', 'program', req.params.id, {});
  res.json({ ok: true });
});

export default router;
