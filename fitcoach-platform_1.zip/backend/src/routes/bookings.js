import express from 'express';
import { v4 as uuid } from 'uuid';
import db from '../db/db.js';
import { requireAuth, requireRole, audit } from '../middleware/auth.js';

const router = express.Router();

router.post('/', requireAuth, requireRole('trainee'), (req, res) => {
  const { coach_id, slot_id, service_type } = req.body;

  const slot = db.prepare(`SELECT * FROM availability_slots WHERE id = ?`).get(slot_id);
  if (!slot || slot.coach_id !== coach_id) return res.status(404).json({ error: 'Slot not found for this coach' });
  if (slot.is_booked) return res.status(409).json({ error: 'This slot has already been booked' });

  const coachProfile = db.prepare(`SELECT * FROM coach_profiles WHERE user_id = ?`).get(coach_id);
  const price = coachProfile?.hourly_rate || 0;

  const id = uuid();
  const txn = db.transaction(() => {
    db.prepare(`UPDATE availability_slots SET is_booked = 1 WHERE id = ?`).run(slot_id);
    db.prepare(
      `INSERT INTO bookings (id, trainee_id, coach_id, slot_id, status, service_type, price)
       VALUES (?,?,?,?, 'confirmed', ?, ?)`
    ).run(id, req.user.id, coach_id, slot_id, service_type || '1:1 session', price);
    // Mocked payment provider — flag stubbed until real Stripe credentials are supplied.
    db.prepare(
      `INSERT INTO payments (id, booking_id, amount, status, provider_ref) VALUES (?,?,?, 'paid', ?)`
    ).run(uuid(), id, price, `mock_stub_${uuid().slice(0, 8)}`);
  });
  txn();

  audit(req.user.id, 'booking_created', 'booking', id, { coach_id, slot_id });
  res.status(201).json({ id, status: 'confirmed', price });
});

router.get('/mine', requireAuth, (req, res) => {
  const col = req.user.role === 'coach' ? 'coach_id' : 'trainee_id';
  const rows = db
    .prepare(
      `SELECT b.*, s.start_time, s.end_time, u.name as counterpart_name
       FROM bookings b
       JOIN availability_slots s ON s.id = b.slot_id
       JOIN users u ON u.id = ${col === 'coach_id' ? 'b.trainee_id' : 'b.coach_id'}
       WHERE b.${col} = ? ORDER BY s.start_time ASC`
    )
    .all(req.user.id);
  res.json(rows);
});

router.put('/:id/status', requireAuth, (req, res) => {
  const { status } = req.body; // confirmed|cancelled|completed
  const booking = db.prepare(`SELECT * FROM bookings WHERE id = ?`).get(req.params.id);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const isOwner = booking.trainee_id === req.user.id || booking.coach_id === req.user.id;
  if (!isOwner && req.user.role !== 'admin') return res.status(403).json({ error: 'Not authorized' });

  db.prepare(`UPDATE bookings SET status = ? WHERE id = ?`).run(status, req.params.id);
  if (status === 'cancelled') {
    db.prepare(`UPDATE availability_slots SET is_booked = 0 WHERE id = ?`).run(booking.slot_id);
  }
  audit(req.user.id, 'booking_status_changed', 'booking', req.params.id, { status, adminOverride: req.user.role === 'admin' });
  res.json({ ok: true });
});

export default router;
