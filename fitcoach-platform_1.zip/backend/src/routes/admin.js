import express from 'express';
import db from '../db/db.js';
import { requireAuth, requireRole, requireAdminScope, audit, signToken } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth, requireRole('admin'));

// --- Platform dashboard ---
router.get('/dashboard', requireAdminScope('support', 'finance'), (req, res) => {
  const activeUsers = db.prepare(`SELECT COUNT(*) as c FROM users WHERE status='active'`).get().c;
  const bookingsToday = db
    .prepare(`SELECT COUNT(*) as c FROM bookings WHERE date(created_at) = date('now')`)
    .get().c;
  const revenue = db.prepare(`SELECT COALESCE(SUM(amount),0) as t FROM payments WHERE status='paid'`).get().t;
  const coachCount = db.prepare(`SELECT COUNT(*) as c FROM users WHERE role='coach' AND status='active'`).get().c;
  const pendingCoaches = db
    .prepare(`SELECT COUNT(*) as c FROM coach_profiles WHERE verification_status='pending'`)
    .get().c;
  const topSpecialties = {};
  db.prepare(`SELECT specialties_json FROM coach_profiles`).all().forEach((r) => {
    JSON.parse(r.specialties_json).forEach((s) => (topSpecialties[s] = (topSpecialties[s] || 0) + 1));
  });

  res.json({ activeUsers, bookingsToday, revenue, coachCount, pendingCoaches, topSpecialties });
});

// --- User management ---
router.get('/users', (req, res) => {
  const { q, role } = req.query;
  let sql = `SELECT id, role, name, email, status, admin_scope, created_at FROM users WHERE 1=1`;
  const params = [];
  if (role) { sql += ` AND role = ?`; params.push(role); }
  if (q) { sql += ` AND (name LIKE ? OR email LIKE ?)`; params.push(`%${q}%`, `%${q}%`); }
  res.json(db.prepare(sql).all(...params));
});

router.put('/users/:id/status', requireAdminScope('superadmin', 'support'), (req, res) => {
  const { status } = req.body; // active|suspended|banned
  db.prepare(`UPDATE users SET status = ? WHERE id = ?`).run(status, req.params.id);
  audit(req.user.id, 'user_status_changed', 'user', req.params.id, { status });
  res.json({ ok: true });
});

router.post('/users/:id/reset-password', requireAdminScope('superadmin', 'support'), (req, res) => {
  // In production this would email a reset link; here we log the audited action only.
  audit(req.user.id, 'password_reset_initiated', 'user', req.params.id, {});
  res.json({ ok: true, note: 'Password reset link would be emailed (stubbed).' });
});

router.post('/users/:id/impersonate', requireAdminScope('superadmin'), (req, res) => {
  const target = db.prepare(`SELECT * FROM users WHERE id = ?`).get(req.params.id);
  if (!target) return res.status(404).json({ error: 'User not found' });
  audit(req.user.id, 'impersonation_started', 'user', target.id, { adminId: req.user.id });
  const token = signToken({ id: target.id, role: target.role, admin_scope: target.admin_scope });
  res.json({ token, user: { id: target.id, role: target.role, name: target.name, email: target.email } });
});

// --- Coach application review queue ---
router.get('/coach-applications', requireAdminScope('superadmin', 'support'), (req, res) => {
  const rows = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.created_at, cp.bio, cp.specialties_json, cp.certifications_json, cp.verification_status
       FROM users u JOIN coach_profiles cp ON cp.user_id = u.id
       WHERE cp.verification_status = 'pending'`
    )
    .all()
    .map((r) => ({ ...r, specialties: JSON.parse(r.specialties_json), certifications: JSON.parse(r.certifications_json) }));
  res.json(rows);
});

router.put('/coach-applications/:userId', requireAdminScope('superadmin', 'support'), (req, res) => {
  const { decision, notes } = req.body; // approve | reject
  const status = decision === 'approve' ? 'approved' : 'rejected';
  db.prepare(`UPDATE coach_profiles SET verification_status = ? WHERE user_id = ?`).run(status, req.params.userId);
  if (decision === 'approve') {
    db.prepare(`UPDATE users SET status = 'active' WHERE id = ?`).run(req.params.userId);
  }
  audit(req.user.id, 'coach_application_reviewed', 'user', req.params.userId, { decision, notes });
  res.json({ ok: true });
});

// --- Catalog / pricing policy (simplified global config) ---
router.get('/catalog', (req, res) => {
  res.json(
    db.prepare(`SELECT id, name, hourly_rate, specialties_json, verification_status FROM coach_profiles cp
      JOIN users u ON u.id = cp.user_id`).all()
  );
});

// --- Moderation ---
router.get('/moderation/reviews', requireAdminScope('superadmin', 'support'), (req, res) => {
  res.json(db.prepare(`SELECT * FROM reviews WHERE moderation_status = 'pending'`).all());
});

router.put('/moderation/reviews/:id', requireAdminScope('superadmin', 'support'), (req, res) => {
  const { decision } = req.body; // approve | reject
  db.prepare(`UPDATE reviews SET moderation_status = ? WHERE id = ?`).run(
    decision === 'approve' ? 'approved' : 'rejected', req.params.id
  );
  audit(req.user.id, 'review_moderated', 'review', req.params.id, { decision });
  res.json({ ok: true });
});

// --- Financials ---
router.get('/financials', requireAdminScope('superadmin', 'finance'), (req, res) => {
  const payments = db
    .prepare(
      `SELECT p.*, b.trainee_id, b.coach_id FROM payments p JOIN bookings b ON b.id = p.booking_id ORDER BY p.rowid DESC`
    )
    .all();
  const totalRevenue = payments.reduce((s, p) => s + (p.status === 'paid' ? p.amount : 0), 0);
  res.json({ payments, totalRevenue });
});

// --- Audit log viewer ---
router.get('/audit-logs', requireAdminScope('superadmin'), (req, res) => {
  const rows = db.prepare(`SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 200`).all();
  res.json(rows.map((r) => ({ ...r, metadata: JSON.parse(r.metadata_json || '{}') })));
});

export default router;
