import express from 'express';
import { v4 as uuid } from 'uuid';
import db from '../db/db.js';
import { requireAuth, requireRole, audit } from '../middleware/auth.js';

const router = express.Router();

// --- Reviews ---
router.post('/reviews', requireAuth, requireRole('trainee'), (req, res) => {
  const { coach_id, rating, comment } = req.body;
  const id = uuid();
  db.prepare(
    `INSERT INTO reviews (id, trainee_id, coach_id, rating, comment) VALUES (?,?,?,?,?)`
  ).run(id, req.user.id, coach_id, rating, comment || '');
  res.status(201).json({ id, moderation_status: 'pending' });
});

router.get('/reviews/:coachId', requireAuth, (req, res) => {
  const rows = db
    .prepare(`SELECT * FROM reviews WHERE coach_id = ? AND moderation_status = 'approved'`)
    .all(req.params.coachId);
  res.json(rows);
});

// --- Messages ---
router.post('/messages', requireAuth, (req, res) => {
  const { recipient_id, body } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: 'Message body cannot be empty' });
  const id = uuid();
  db.prepare(`INSERT INTO messages (id, sender_id, recipient_id, body) VALUES (?,?,?,?)`).run(
    id, req.user.id, recipient_id, body
  );
  res.status(201).json({ id });
});

router.get('/messages/:counterpartId', requireAuth, (req, res) => {
  const rows = db
    .prepare(
      `SELECT * FROM messages WHERE (sender_id = ? AND recipient_id = ?) OR (sender_id = ? AND recipient_id = ?)
       ORDER BY created_at ASC`
    )
    .all(req.user.id, req.params.counterpartId, req.params.counterpartId, req.user.id);
  res.json(rows);
});

export default router;
