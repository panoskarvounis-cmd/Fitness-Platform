import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.js';
import traineeRoutes from './routes/trainee.js';
import coachRoutes from './routes/coach.js';
import bookingRoutes from './routes/bookings.js';
import socialRoutes from './routes/social.js';
import adminRoutes from './routes/admin.js';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'fitcoach-backend' }));

app.use('/api/auth', authRoutes);
app.use('/api/trainee', traineeRoutes);
app.use('/api/coach', coachRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api', socialRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`FitCoach backend running on http://localhost:${PORT}`));
