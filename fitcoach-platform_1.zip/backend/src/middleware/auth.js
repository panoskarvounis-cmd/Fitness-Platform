import jwt from 'jsonwebtoken';
import db from '../db/db.js';
import { v4 as uuid } from 'uuid';

export const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production';

export function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, admin_scope: user.admin_scope || null },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }
  try {
    const payload = jwt.verify(header.slice(7), JWT_SECRET);
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// Centralized RBAC: pass allowed roles. Never bypassed per-endpoint ad hoc.
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions for this action' });
    }
    next();
  };
}

// Admins can be scoped: support | finance | superadmin
export function requireAdminScope(...scopes) {
  return (req, res, next) => {
    if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
    if (scopes.length && !scopes.includes(req.user.admin_scope) && req.user.admin_scope !== 'superadmin') {
      return res.status(403).json({ error: `Requires admin scope: ${scopes.join(' or ')}` });
    }
    next();
  };
}

export function audit(actorId, action, targetType, targetId, metadata = {}) {
  db.prepare(
    `INSERT INTO audit_logs (id, actor_id, action, target_type, target_id, metadata_json) VALUES (?,?,?,?,?,?)`
  ).run(uuid(), actorId, action, targetType, targetId, JSON.stringify(metadata));
}
