// Rules-based recommendation engine.
// IMPORTANT: This never produces a medical diagnosis. It only drafts a
// starting-point training direction from structured intake answers. The
// output is always stored as a `programs` row with status:'draft' and must
// be reviewed/approved/edited by the assigned coach before a trainee's plan
// goes active. Red-flagged (PAR-Q positive) trainees are handled the same
// way but the draft explicitly recommends medical clearance first.

const RED_FLAG_KEYS = ['heart_condition', 'chest_pain', 'dizziness', 'bone_joint_problem', 'blood_pressure_meds', 'other_reason_not_to_exercise'];

export function evaluateParQ(answers) {
  const flagged = RED_FLAG_KEYS.some((k) => answers[k] === true);
  return flagged;
}

export function buildRecommendation(answers, objectiveType, activityLevel) {
  const rulesFired = [];
  const parqFlag = evaluateParQ(answers);

  let split = 'full_body';
  let frequency = 3;
  let intensityZone = 'moderate';
  const restrictions = [];

  if (parqFlag) {
    rulesFired.push('PARQ_POSITIVE -> require medical clearance before intensity ramp, cap intensity at "light"');
    intensityZone = 'light';
    restrictions.push('Requires medical clearance sign-off before progressing beyond light intensity.');
  }

  if (activityLevel === 'sedentary') {
    rulesFired.push('ACTIVITY_SEDENTARY -> frequency=2-3, full_body split, light-moderate intensity');
    frequency = Math.min(frequency, 3);
    if (intensityZone !== 'light') intensityZone = 'moderate';
  } else if (activityLevel === 'active') {
    rulesFired.push('ACTIVITY_ACTIVE -> frequency up to 4-5, split routine allowed');
    frequency = parqFlag ? 3 : 5;
    split = parqFlag ? 'full_body' : 'upper_lower';
  }

  if (objectiveType === 'weight_loss') {
    rulesFired.push('OBJECTIVE_WEIGHT_LOSS -> emphasize metabolic conditioning + full body compound movements');
  } else if (objectiveType === 'muscle_gain') {
    rulesFired.push('OBJECTIVE_MUSCLE_GAIN -> emphasize progressive overload, split routine if activity allows');
    if (!parqFlag && activityLevel !== 'sedentary') split = 'push_pull_legs';
  } else if (objectiveType === 'rehab') {
    rulesFired.push('OBJECTIVE_REHAB -> low intensity, mobility-first, defer to coach for contraindicated movements');
    intensityZone = 'light';
    restrictions.push('Avoid high-impact and contraindicated movements pending coach review of injury history.');
  } else if (objectiveType === 'endurance') {
    rulesFired.push('OBJECTIVE_ENDURANCE -> add cardio-dominant sessions, moderate resistance work');
  }

  if (answers.pregnancy_status === true) {
    rulesFired.push('PREGNANCY_TRUE -> exclude supine/high-impact work, require coach + medical sign-off');
    restrictions.push('Exclude supine and high-impact exercises; requires coach and medical sign-off.');
    intensityZone = 'light';
  }

  if (Array.isArray(answers.injuries) && answers.injuries.length) {
    rulesFired.push(`INJURIES_PRESENT(${answers.injuries.join(',')}) -> tag contraindicated movements for coach review`);
    restrictions.push(`Flag exercises contraindicated for reported injuries: ${answers.injuries.join(', ')}.`);
  }

  return {
    parqFlag,
    draft: {
      split,
      frequencyPerWeek: frequency,
      intensityZone,
      restrictions,
      progressionCadence: 'Reassess and adjust load every 2 weeks based on adherence and RPE.',
    },
    rulesFired,
  };
}
