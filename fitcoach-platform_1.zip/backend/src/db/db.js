import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '../../data/fitcoach.sqlite');

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  role TEXT NOT NULL CHECK(role IN ('trainee','coach','admin')),
  admin_scope TEXT, -- 'support' | 'finance' | 'superadmin' (admins only)
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active', -- active | pending | suspended | banned
  mfa_enabled INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trainee_profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id),
  activity_level TEXT,
  budget_pref TEXT,
  demographics_json TEXT
);

CREATE TABLE IF NOT EXISTS coach_profiles (
  user_id TEXT PRIMARY KEY REFERENCES users(id),
  bio TEXT,
  specialties_json TEXT DEFAULT '[]',
  hourly_rate REAL DEFAULT 0,
  certifications_json TEXT DEFAULT '[]',
  verification_status TEXT DEFAULT 'pending' -- pending | approved | rejected
);

CREATE TABLE IF NOT EXISTS health_intakes (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  version INTEGER NOT NULL,
  answers_json TEXT NOT NULL,
  parq_flag INTEGER DEFAULT 0,
  submitted_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS objectives (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  type TEXT,
  target_value REAL,
  target_date TEXT,
  status TEXT DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS availability_slots (
  id TEXT PRIMARY KEY,
  coach_id TEXT NOT NULL REFERENCES users(id),
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  is_booked INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  coach_id TEXT NOT NULL REFERENCES users(id),
  slot_id TEXT REFERENCES availability_slots(id),
  status TEXT DEFAULT 'requested', -- requested|confirmed|completed|cancelled
  service_type TEXT,
  price REAL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS programs (
  id TEXT PRIMARY KEY,
  coach_id TEXT NOT NULL REFERENCES users(id),
  trainee_id TEXT NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  source TEXT DEFAULT 'custom', -- template|custom|ai_suggested
  status TEXT DEFAULT 'draft', -- draft|active|archived
  version INTEGER DEFAULT 1,
  rules_json TEXT, -- rules that produced an ai_suggested program
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS program_items (
  id TEXT PRIMARY KEY,
  program_id TEXT NOT NULL REFERENCES programs(id),
  day_index INTEGER,
  exercise_id TEXT REFERENCES exercise_library(id),
  sets INTEGER,
  reps INTEGER,
  weight REAL,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS exercise_library (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  muscle_groups_json TEXT DEFAULT '[]',
  equipment TEXT,
  media_url TEXT,
  contraindication_tags_json TEXT DEFAULT '[]',
  difficulty TEXT
);

CREATE TABLE IF NOT EXISTS workout_logs (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  program_item_id TEXT REFERENCES program_items(id),
  date TEXT DEFAULT (datetime('now')),
  actual_sets INTEGER,
  actual_reps INTEGER,
  actual_weight REAL,
  rpe INTEGER
);

CREATE TABLE IF NOT EXISTS body_metrics (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  date TEXT DEFAULT (datetime('now')),
  weight REAL,
  body_fat_pct REAL,
  measurements_json TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  booking_id TEXT REFERENCES bookings(id),
  amount REAL,
  status TEXT DEFAULT 'paid', -- mocked provider
  provider_ref TEXT
);

CREATE TABLE IF NOT EXISTS reviews (
  id TEXT PRIMARY KEY,
  trainee_id TEXT NOT NULL REFERENCES users(id),
  coach_id TEXT NOT NULL REFERENCES users(id),
  rating INTEGER,
  comment TEXT,
  moderation_status TEXT DEFAULT 'pending' -- pending|approved|rejected
);

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  sender_id TEXT NOT NULL REFERENCES users(id),
  recipient_id TEXT NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  metadata_json TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
`);

export default db;
