import bcrypt from 'bcryptjs';
import { v4 as uuid } from 'uuid';
import db from './db.js';

const hash = (pw) => bcrypt.hashSync(pw, 10);

function upsertUser({ id, role, name, email, password, status = 'active', admin_scope = null }) {
  db.prepare(
    `INSERT OR IGNORE INTO users (id, role, admin_scope, name, email, password_hash, status) VALUES (?,?,?,?,?,?,?)`
  ).run(id, role, admin_scope, name, email, hash(password), status);
}

console.log('Seeding FitCoach database...');

// --- Admin ---
const adminId = 'admin-1';
upsertUser({ id: adminId, role: 'admin', name: 'Ava Admin', email: 'admin@fitcoach.dev', password: 'admin123', admin_scope: 'superadmin' });

// --- Coaches ---
const coach1 = 'coach-1';
upsertUser({ id: coach1, role: 'coach', name: 'Marcus Lee', email: 'marcus@fitcoach.dev', password: 'coach123' });
db.prepare(`INSERT OR IGNORE INTO coach_profiles (user_id, bio, specialties_json, hourly_rate, certifications_json, verification_status)
  VALUES (?,?,?,?,?, 'approved')`).run(
  coach1, 'NASM-certified strength coach, 8 years experience with rehab clients.',
  JSON.stringify(['strength', 'rehab']), 55, JSON.stringify(['NASM-CPT', 'CES'])
);

const coach2 = 'coach-2';
upsertUser({ id: coach2, role: 'coach', name: 'Priya Nair', email: 'priya@fitcoach.dev', password: 'coach123' });
db.prepare(`INSERT OR IGNORE INTO coach_profiles (user_id, bio, specialties_json, hourly_rate, certifications_json, verification_status)
  VALUES (?,?,?,?,?, 'approved')`).run(
  coach2, 'Endurance & marathon prep specialist. Former collegiate runner.',
  JSON.stringify(['endurance', 'weight_loss']), 45, JSON.stringify(['RRCA', 'ACE-CPT'])
);

const coach3 = 'coach-3'; // pending application, for admin approval demo
upsertUser({ id: coach3, role: 'coach', name: 'Diego Fernandez', email: 'diego@fitcoach.dev', password: 'coach123', status: 'pending' });
db.prepare(`INSERT OR IGNORE INTO coach_profiles (user_id, bio, specialties_json, hourly_rate, certifications_json, verification_status)
  VALUES (?,?,?,?,?, 'pending')`).run(
  coach3, 'Bodybuilding & hypertrophy coach, competed nationally.',
  JSON.stringify(['muscle_gain']), 60, JSON.stringify(['ISSA-CPT'])
);

// --- Trainees ---
const trainee1 = 'trainee-1';
upsertUser({ id: trainee1, role: 'trainee', name: 'Sam Rivera', email: 'sam@fitcoach.dev', password: 'trainee123' });
db.prepare(`INSERT OR IGNORE INTO trainee_profiles (user_id, activity_level, budget_pref) VALUES (?, 'sedentary', 'medium')`).run(trainee1);

const trainee2 = 'trainee-2';
upsertUser({ id: trainee2, role: 'trainee', name: 'Jordan Kim', email: 'jordan@fitcoach.dev', password: 'trainee123' });
db.prepare(`INSERT OR IGNORE INTO trainee_profiles (user_id, activity_level, budget_pref) VALUES (?, 'active', 'high')`).run(trainee2);

// --- Health intakes ---
db.prepare(`INSERT OR IGNORE INTO health_intakes (id, trainee_id, version, answers_json, parq_flag) VALUES (?,?,?,?,?)`).run(
  uuid(), trainee1, 1,
  JSON.stringify({ age: 34, sex: 'M', height_cm: 178, weight_kg: 92, injuries: ['lower_back'], chronic_conditions: [], medications: [], pregnancy_status: false, heart_condition: false, chest_pain: false, dizziness: false, bone_joint_problem: true, blood_pressure_meds: false, other_reason_not_to_exercise: false }),
  1
);
db.prepare(`INSERT OR IGNORE INTO objectives (id, trainee_id, type, target_value, target_date) VALUES (?,?,?,?,?)`).run(
  uuid(), trainee1, 'weight_loss', 82, '2026-12-31'
);
db.prepare(`INSERT OR IGNORE INTO body_metrics (id, trainee_id, weight, body_fat_pct) VALUES (?,?,?,?)`).run(uuid(), trainee1, 92, 28);
db.prepare(`INSERT OR IGNORE INTO body_metrics (id, trainee_id, weight, body_fat_pct) VALUES (?,?,?,?)`).run(uuid(), trainee1, 89.5, 26.5);

db.prepare(`INSERT OR IGNORE INTO health_intakes (id, trainee_id, version, answers_json, parq_flag) VALUES (?,?,?,?,?)`).run(
  uuid(), trainee2, 1,
  JSON.stringify({ age: 27, sex: 'F', height_cm: 165, weight_kg: 60, injuries: [], chronic_conditions: [], medications: [], pregnancy_status: false, heart_condition: false, chest_pain: false, dizziness: false, bone_joint_problem: false, blood_pressure_meds: false, other_reason_not_to_exercise: false }),
  0
);
db.prepare(`INSERT OR IGNORE INTO objectives (id, trainee_id, type, target_value, target_date) VALUES (?,?,?,?,?)`).run(
  uuid(), trainee2, 'endurance', null, '2026-11-01'
);

// --- Exercise library ---
const exercises = [
  ['Bodyweight Squat', ['legs', 'glutes'], 'none', 'beginner', []],
  ['Goblet Squat', ['legs', 'glutes'], 'dumbbell', 'beginner', ['lower_back']],
  ['Push-Up', ['chest', 'triceps'], 'none', 'beginner', []],
  ['Bent-Over Row', ['back', 'biceps'], 'barbell', 'intermediate', ['lower_back']],
  ['Plank', ['core'], 'none', 'beginner', []],
  ['Deadlift', ['back', 'legs', 'glutes'], 'barbell', 'advanced', ['lower_back']],
  ['Walking Lunge', ['legs', 'glutes'], 'none', 'beginner', ['knee']],
  ['Treadmill Intervals', ['cardio'], 'treadmill', 'intermediate', []],
  ['Seated Row Machine', ['back', 'biceps'], 'machine', 'beginner', []],
  ['Overhead Press', ['shoulders', 'triceps'], 'dumbbell', 'intermediate', ['shoulder']],
];
const exerciseIds = {};
for (const [name, groups, equip, diff, contra] of exercises) {
  const id = uuid();
  exerciseIds[name] = id;
  db.prepare(
    `INSERT OR IGNORE INTO exercise_library (id, name, muscle_groups_json, equipment, difficulty, contraindication_tags_json)
     VALUES (?,?,?,?,?,?)`
  ).run(id, name, JSON.stringify(groups), equip, diff, JSON.stringify(contra));
}

// --- Sample program for trainee1 (draft, coach1) ---
const progId = uuid();
db.prepare(`INSERT OR IGNORE INTO programs (id, coach_id, trainee_id, title, source, status) VALUES (?,?,?,?,?, 'active')`).run(
  progId, coach1, trainee1, 'Full Body Foundations - Weeks 1-4', 'custom'
);
const items = [
  [0, 'Bodyweight Squat', 3, 12, null],
  [0, 'Push-Up', 3, 10, null],
  [0, 'Plank', 3, null, 'Hold 30-45s'],
  [2, 'Goblet Squat', 3, 10, 12],
  [2, 'Seated Row Machine', 3, 12, 20],
];
for (const [day, exName, sets, reps, weight] of items) {
  db.prepare(
    `INSERT INTO program_items (id, program_id, day_index, exercise_id, sets, reps, weight, notes) VALUES (?,?,?,?,?,?,?,?)`
  ).run(uuid(), progId, day, exerciseIds[exName], sets, reps, weight, '');
}

// A couple of logged workouts for KPI demo
const firstItem = db.prepare(`SELECT id FROM program_items WHERE program_id = ? LIMIT 1`).get(progId);
db.prepare(`INSERT INTO workout_logs (id, trainee_id, program_item_id, actual_sets, actual_reps, actual_weight, rpe) VALUES (?,?,?,?,?,?,?)`)
  .run(uuid(), trainee1, firstItem.id, 3, 12, 0, 6);

// --- Availability slots for coaches ---
const now = new Date();
function iso(offsetDays, hour) {
  const d = new Date(now);
  d.setDate(d.getDate() + offsetDays);
  d.setHours(hour, 0, 0, 0);
  return d.toISOString();
}
for (let i = 1; i <= 5; i++) {
  db.prepare(`INSERT INTO availability_slots (id, coach_id, start_time, end_time) VALUES (?,?,?,?)`).run(
    uuid(), coach1, iso(i, 9), iso(i, 10)
  );
  db.prepare(`INSERT INTO availability_slots (id, coach_id, start_time, end_time) VALUES (?,?,?,?)`).run(
    uuid(), coach2, iso(i, 17), iso(i, 18)
  );
}

// --- Reviews (one pending, one approved) ---
db.prepare(`INSERT INTO reviews (id, trainee_id, coach_id, rating, comment, moderation_status) VALUES (?,?,?,?,?, 'approved')`)
  .run(uuid(), trainee2, coach2, 5, 'Priya\'s pacing plan got me a 10k PR!');
db.prepare(`INSERT INTO reviews (id, trainee_id, coach_id, rating, comment, moderation_status) VALUES (?,?,?,?,?, 'pending')`)
  .run(uuid(), trainee1, coach1, 4, 'Solid coaching, very attentive to my back issue.');

console.log('Seed complete.');
console.log('--- Demo logins ---');
console.log('Admin:   admin@fitcoach.dev / admin123');
console.log('Coach:   marcus@fitcoach.dev / coach123 (approved)');
console.log('Coach:   priya@fitcoach.dev / coach123 (approved)');
console.log('Coach:   diego@fitcoach.dev / coach123 (pending approval — try approving via admin)');
console.log('Trainee: sam@fitcoach.dev / trainee123 (PAR-Q flagged, has active program)');
console.log('Trainee: jordan@fitcoach.dev / trainee123');
